use bytes::BytesMut;
use luma_ffi::{FfiConfig, FfiDeviceCommand, LumaApi};
use mqttbytes::v4::{Connect, ConnectReturnCode, Packet, Publish, Subscribe, SubscribeFilter};
use mqttbytes::QoS;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::TcpStream;
use tokio::time::{timeout, Duration};

fn test_config(db_path: &str, broker_port: u16) -> FfiConfig {
    let _ = std::fs::remove_file(db_path);
    FfiConfig {
        home_id: "test-home".into(),
        db_path: db_path.into(),
        broker_bind_addr: "127.0.0.1".into(),
        broker_port,
        broker_require_auth: false,
        broker_home_secret: None,
        enable_cloud_bridge: false,
        cloud_mqtt_host: None,
        cloud_mqtt_port: None,
        cloud_mqtt_client_id: None,
        cloud_mqtt_username: None,
        cloud_mqtt_password: None,
        cloud_mqtt_use_tls: false,
    }
}

/// A minimal raw-socket MQTT client standing in for real ESP32 firmware, so
/// these tests exercise the actual wire protocol the broker speaks rather
/// than calling broker internals directly.
struct FakeDevice {
    stream: TcpStream,
    buf: BytesMut,
}

impl FakeDevice {
    async fn connect(port: u16, client_id: &str, clean_session: bool) -> (Self, ConnectReturnCode, bool) {
        let stream = TcpStream::connect(("127.0.0.1", port)).await.expect("tcp connect");
        let mut dev = Self { stream, buf: BytesMut::with_capacity(1024) };
        let mut connect = Connect::new(client_id);
        connect.clean_session = clean_session;
        connect.keep_alive = 30;
        dev.write(&Packet::Connect(connect)).await;
        match dev.read().await.expect("expected CONNACK") {
            Packet::ConnAck(ack) => (dev, ack.code, ack.session_present),
            _ => panic!("expected CONNACK as first packet"),
        }
    }

    async fn write(&mut self, packet: &Packet) {
        let mut out = BytesMut::new();
        match packet {
            Packet::Connect(p) => p.write(&mut out).map(|_| ()).unwrap(),
            Packet::Subscribe(p) => p.write(&mut out).map(|_| ()).unwrap(),
            Packet::Publish(p) => p.write(&mut out).map(|_| ()).unwrap(),
            Packet::PubAck(p) => p.write(&mut out).map(|_| ()).unwrap(),
            Packet::Disconnect => mqttbytes::v4::Disconnect.write(&mut out).map(|_| ()).unwrap(),
            Packet::PingReq => mqttbytes::v4::PingReq.write(&mut out).map(|_| ()).unwrap(),
            _ => panic!("test helper doesn't send this packet type"),
        };
        self.stream.write_all(&out).await.expect("write_all");
    }

    async fn read(&mut self) -> Option<Packet> {
        loop {
            match mqttbytes::v4::read(&mut self.buf, 256 * 1024) {
                Ok(packet) => return Some(packet),
                Err(mqttbytes::Error::InsufficientBytes(_)) => {
                    let mut chunk = [0u8; 2048];
                    let n = self.stream.read(&mut chunk).await.ok()?;
                    if n == 0 {
                        return None;
                    }
                    self.buf.extend_from_slice(&chunk[..n]);
                }
                Err(_) => return None,
            }
        }
    }

    async fn read_timeout(&mut self, ms: u64) -> Option<Packet> {
        timeout(Duration::from_millis(ms), self.read()).await.unwrap_or(None)
    }

    async fn subscribe(&mut self, filter: &str) {
        let sub = Subscribe { pkid: 1, filters: vec![SubscribeFilter::new(filter.to_string(), QoS::AtLeastOnce)] };
        self.write(&Packet::Subscribe(sub)).await;
        match self.read_timeout(1000).await {
            Some(Packet::SubAck(_)) => {}
            other => panic!("expected SUBACK, got {}", describe(&other)),
        }
    }

    async fn publish(&mut self, topic: &str, payload: &str, qos: QoS, retain: bool) {
        let mut p = Publish::new(topic, qos, payload.as_bytes().to_vec());
        p.retain = retain;
        p.pkid = 7;
        self.write(&Packet::Publish(p)).await;
        if qos != QoS::AtMostOnce {
            match self.read_timeout(1000).await {
                Some(Packet::PubAck(_)) => {}
                other => panic!("expected PUBACK, got {}", describe(&other)),
            }
        }
    }

    async fn expect_publish(&mut self, ms: u64) -> Publish {
        match self.read_timeout(ms).await {
            Some(Packet::Publish(p)) => p,
            other => panic!("expected PUBLISH, got {}", describe(&other)),
        }
    }
}

fn describe(p: &Option<Packet>) -> &'static str {
    match p {
        None => "nothing (timeout/closed)",
        Some(Packet::ConnAck(_)) => "CONNACK",
        Some(Packet::Publish(_)) => "PUBLISH",
        Some(Packet::PubAck(_)) => "PUBACK",
        Some(Packet::SubAck(_)) => "SUBACK",
        _ => "some other packet",
    }
}

#[test]
fn engine_starts_broker_and_reports_capacity() {
    let api = LumaApi::new(test_config("/tmp/luma_broker_test_1.db", 19101)).expect("construct api");
    api.start_engine().expect("start");
    assert_eq!(api.engine_state(), "Running");

    let stats = api.get_mqtt_monitor();
    assert_eq!(stats.max_clients, 5);
    assert_eq!(stats.connected_clients, 0);
    assert_eq!(stats.port, 19101);

    api.stop_engine().expect("stop");
}

#[test]
fn typed_command_delivered_to_subscribed_device() {
    let api = LumaApi::new(test_config("/tmp/luma_broker_test_2.db", 19102)).expect("construct api");
    api.start_engine().expect("start");

    let rt = tokio::runtime::Runtime::new().unwrap();
    rt.block_on(async {
        let (mut dev, code, _) = FakeDevice::connect(19102, "dev-1", true).await;
        assert_eq!(code, ConnectReturnCode::Success);
        dev.subscribe("device/dev-1/command").await;

        api.send_command("dev-1".into(), FfiDeviceCommand::Brightness { value: 80 }).expect("send command");

        let publish = dev.expect_publish(1000).await;
        assert_eq!(publish.topic, "device/dev-1/command");
        let value: serde_json::Value = serde_json::from_slice(&publish.payload).unwrap();
        assert_eq!(value["cmd"], "brightness");
        assert_eq!(value["value"], 80);
    });

    let clients = api.get_connected_clients();
    assert_eq!(clients.len(), 1);
    assert!(clients[0].connected);
    assert_eq!(clients[0].subscriptions, vec!["device/dev-1/command".to_string()]);

    api.stop_engine().expect("stop");
}

#[test]
fn sensor_data_updates_device_shadow() {
    let api = LumaApi::new(test_config("/tmp/luma_broker_test_3.db", 19103)).expect("construct api");
    api.start_engine().expect("start");

    let rt = tokio::runtime::Runtime::new().unwrap();
    rt.block_on(async {
        let (mut dev, code, _) = FakeDevice::connect(19103, "dev-2", true).await;
        assert_eq!(code, ConnectReturnCode::Success);
        dev.publish("device/dev-2/data", r#"{"temperature": 22.5, "humidity": 41}"#, QoS::AtLeastOnce, false).await;
        // give the automation/storage bridge a beat to process the routed event
        tokio::time::sleep(Duration::from_millis(150)).await;
    });

    let device = api.get_device("dev-2".into()).expect("device should exist after publishing to it");
    let reported: serde_json::Value = serde_json::from_str(&device.reported_state_json).unwrap();
    assert_eq!(reported["temperature"], 22.5);
    assert_eq!(device.status, "Online");

    api.stop_engine().expect("stop");
}

#[test]
fn persistent_session_queues_command_while_offline() {
    let api = LumaApi::new(test_config("/tmp/luma_broker_test_4.db", 19104)).expect("construct api");
    api.start_engine().expect("start");

    let rt = tokio::runtime::Runtime::new().unwrap();
    rt.block_on(async {
        // First connection: persistent session, subscribe, then disconnect
        // ungracefully (just drop the socket) without ever unsubscribing.
        {
            let (mut dev, code, session_present) = FakeDevice::connect(19104, "dev-3", false).await;
            assert_eq!(code, ConnectReturnCode::Success);
            assert!(!session_present, "first connect should be a fresh session");
            dev.subscribe("device/dev-3/command").await;
            // dev drops here, socket closes
        }
        tokio::time::sleep(Duration::from_millis(150)).await;

        // While offline, address a command to it — should land in the durable
        // session queue instead of being lost (design goal: offline message storage).
        api.send_command("dev-3".into(), FfiDeviceCommand::Off).expect("send command while offline");
        tokio::time::sleep(Duration::from_millis(50)).await;

        // Reconnect with the same client_id + clean_session=false: the queued
        // command should be delivered immediately, no fresh publish needed.
        let (mut dev, code, session_present) = FakeDevice::connect(19104, "dev-3", false).await;
        assert_eq!(code, ConnectReturnCode::Success);
        assert!(session_present, "reconnect should resume the persistent session");

        let publish = dev.expect_publish(1000).await;
        assert_eq!(publish.topic, "device/dev-3/command");
        let value: serde_json::Value = serde_json::from_slice(&publish.payload).unwrap();
        assert_eq!(value["cmd"], "off");
    });

    api.stop_engine().expect("stop");
}

#[test]
fn max_five_clients_enforced() {
    let api = LumaApi::new(test_config("/tmp/luma_broker_test_5.db", 19105)).expect("construct api");
    api.start_engine().expect("start");

    let rt = tokio::runtime::Runtime::new().unwrap();
    rt.block_on(async {
        let mut connected = Vec::new();
        for i in 0..5 {
            let (dev, code, _) = FakeDevice::connect(19105, &format!("dev-cap-{i}"), true).await;
            assert_eq!(code, ConnectReturnCode::Success, "device {i} should connect within capacity");
            connected.push(dev); // keep alive - dropping would free its slot
        }

        let (_rejected, code, _) = FakeDevice::connect(19105, "dev-cap-overflow", true).await;
        assert_eq!(code, ConnectReturnCode::ServiceUnavailable, "6th device should be refused: broker is at capacity");
    });

    assert_eq!(api.get_mqtt_monitor().connected_clients, 5);
    api.stop_engine().expect("stop");
}

#[test]
fn retained_message_replayed_on_subscribe() {
    let api = LumaApi::new(test_config("/tmp/luma_broker_test_6.db", 19106)).expect("construct api");
    api.start_engine().expect("start");

    let rt = tokio::runtime::Runtime::new().unwrap();
    rt.block_on(async {
        let (mut publisher, _, _) = FakeDevice::connect(19106, "dev-publisher", true).await;
        publisher.publish("home/all", r#"{"scene":"goodnight"}"#, QoS::AtLeastOnce, true).await;
        tokio::time::sleep(Duration::from_millis(100)).await;

        // A late subscriber should get the retained message immediately on subscribe.
        let (mut subscriber, _, _) = FakeDevice::connect(19106, "dev-subscriber", true).await;
        subscriber.subscribe("home/all").await;
        let publish = subscriber.expect_publish(1000).await;
        assert_eq!(publish.topic, "home/all");
        assert!(publish.retain);
    });

    api.stop_engine().expect("stop");
}
