use luma_automation::AutomationEngine;
use luma_broker::BrokerEngine;
use luma_core::engine::{EngineConfig, EngineController};
use luma_core::error::LumaError;
use luma_core::event_bus::LumaEvent;
use luma_core::models::{Action, Automation, CompareOp, Condition, Device, LogEntry, Scene, TriggerKind};
use luma_mqtt::MqttEngine;
use luma_storage::Storage;
use std::sync::Arc;
use tokio::runtime::Runtime;

uniffi::setup_scaffolding!();

#[derive(Debug, thiserror::Error, uniffi::Error)]
pub enum FfiError {
    #[error("{message}")]
    Failed { message: String },
}

impl From<LumaError> for FfiError {
    fn from(e: LumaError) -> Self {
        FfiError::Failed { message: e.to_string() }
    }
}

#[derive(uniffi::Record, Clone)]
pub struct FfiConfig {
    pub home_id: String,
    pub db_path: String,

    /// The embedded broker — this is the app's primary, offline-first comms
    /// path. `broker_bind_addr` is normally "0.0.0.0" so ESP32s can reach it
    /// over the phone's hotspot or a shared WiFi router (design doc section 4).
    pub broker_bind_addr: String,
    pub broker_port: u16,
    pub broker_require_auth: bool,
    pub broker_home_secret: Option<String>,

    /// Optional bridge to a remote broker for when internet is available
    /// (design doc's "Future Enhancements": secure remote access). Off by
    /// default — the app works fully offline without this.
    pub enable_cloud_bridge: bool,
    pub cloud_mqtt_host: Option<String>,
    pub cloud_mqtt_port: Option<u16>,
    pub cloud_mqtt_client_id: Option<String>,
    pub cloud_mqtt_username: Option<String>,
    pub cloud_mqtt_password: Option<String>,
    pub cloud_mqtt_use_tls: bool,
}

#[derive(uniffi::Record, Clone)]
pub struct FfiDevice {
    pub id: String,
    pub name: String,
    pub room_id: Option<String>,
    pub device_type: String,
    pub firmware_version: String,
    pub mac_address: String,
    pub ip_address: Option<String>,
    pub status: String,
    pub reported_state_json: String,
    pub desired_state_json: String,
}

impl From<Device> for FfiDevice {
    fn from(d: Device) -> Self {
        Self {
            id: d.id,
            name: d.name,
            room_id: d.room_id,
            device_type: d.device_type,
            firmware_version: d.firmware_version,
            mac_address: d.mac_address,
            ip_address: d.ip_address,
            status: format!("{:?}", d.status),
            reported_state_json: d.reported_state.to_string(),
            desired_state_json: d.desired_state.to_string(),
        }
    }
}

#[derive(uniffi::Record, Clone)]
pub struct FfiLogEntry {
    pub id: String,
    pub level: String,
    pub source: String,
    pub message: String,
    pub timestamp: String,
}

impl From<LogEntry> for FfiLogEntry {
    fn from(l: LogEntry) -> Self {
        Self { id: l.id, level: l.level, source: l.source, message: l.message, timestamp: l.timestamp.to_rfc3339() }
    }
}

/// A live (or recently-live, if persisted) entry from the broker's Client
/// Manager — backs the "MQTT Monitor" / "Device List" screens.
#[derive(uniffi::Record, Clone)]
pub struct FfiMqttClient {
    pub client_id: String,
    pub mac_address: Option<String>,
    pub ip_address: String,
    pub connected: bool,
    pub clean_session: bool,
    pub subscriptions: Vec<String>,
    pub connected_at: String,
    pub last_seen: String,
    pub rssi: Option<i32>,
}

impl From<luma_broker::ClientSnapshot> for FfiMqttClient {
    fn from(c: luma_broker::ClientSnapshot) -> Self {
        Self {
            client_id: c.client_id,
            mac_address: c.mac_address,
            ip_address: c.ip_address,
            connected: c.connected,
            clean_session: c.clean_session,
            subscriptions: c.subscriptions,
            connected_at: c.connected_at.to_rfc3339(),
            last_seen: c.last_seen.to_rfc3339(),
            rssi: c.rssi,
        }
    }
}

/// Snapshot for the "MQTT Monitor" screen (design doc section 10).
#[derive(uniffi::Record, Clone)]
pub struct FfiBrokerStats {
    pub port: u16,
    pub connected_clients: u32,
    pub max_clients: u32,
    pub retained_messages: u32,
    pub known_topics: Vec<String>,
}

#[derive(uniffi::Enum, Clone)]
pub enum FfiCompareOp {
    Eq,
    Neq,
    Gt,
    Gte,
    Lt,
    Lte,
}

impl From<FfiCompareOp> for CompareOp {
    fn from(op: FfiCompareOp) -> Self {
        match op {
            FfiCompareOp::Eq => CompareOp::Eq,
            FfiCompareOp::Neq => CompareOp::Neq,
            FfiCompareOp::Gt => CompareOp::Gt,
            FfiCompareOp::Gte => CompareOp::Gte,
            FfiCompareOp::Lt => CompareOp::Lt,
            FfiCompareOp::Lte => CompareOp::Lte,
        }
    }
}

/// Typed command vocabulary from design doc section 8 — gives the UI compile-
/// time-checked buttons/sliders instead of hand-rolled JSON strings. Falls
/// back to `publish_message` for anything custom firmware needs beyond this set.
#[derive(uniffi::Enum, Clone)]
pub enum FfiDeviceCommand {
    On,
    Off,
    Toggle,
    Brightness { value: u8 },
    Rgb { r: u8, g: u8, b: u8 },
    FanSpeed { value: u8 },
    ServoAngle { degrees: u16 },
    Restart,
    FactoryReset,
}

impl From<FfiDeviceCommand> for luma_core::models::DeviceCommand {
    fn from(c: FfiDeviceCommand) -> Self {
        use luma_core::models::DeviceCommand as DC;
        match c {
            FfiDeviceCommand::On => DC::On,
            FfiDeviceCommand::Off => DC::Off,
            FfiDeviceCommand::Toggle => DC::Toggle,
            FfiDeviceCommand::Brightness { value } => DC::Brightness { value },
            FfiDeviceCommand::Rgb { r, g, b } => DC::Rgb { r, g, b },
            FfiDeviceCommand::FanSpeed { value } => DC::FanSpeed { value },
            FfiDeviceCommand::ServoAngle { degrees } => DC::ServoAngle { degrees },
            FfiDeviceCommand::Restart => DC::Restart,
            FfiDeviceCommand::FactoryReset => DC::FactoryReset,
        }
    }
}

#[derive(uniffi::Record, Clone)]
pub struct FfiAutomationSpec {
    pub name: String,
    /// Device whose state change should trigger this automation.
    pub trigger_device_id: String,
    pub trigger_path: String,
    pub trigger_op: FfiCompareOp,
    /// JSON-encoded value to compare against.
    pub trigger_value_json: String,
    /// Each condition: "device_id|path|op|value_json" (kept as flat strings to
    /// cross the FFI boundary cheaply; the RN side builds these from form state).
    pub condition_specs: Vec<String>,
    /// Each action: "device_id|desired_state_json"
    pub action_specs: Vec<String>,
}

/// The single object the mobile bridge (JSI/TurboModule) holds a handle to.
/// One instance per running app; internally owns its own tokio runtime so the
/// UI thread never blocks on async engine work.
#[derive(uniffi::Object)]
pub struct LumaApi {
    runtime: Runtime,
    controller: Arc<EngineController>,
    storage: Storage,
    broker: Arc<BrokerEngine>,
    broker_port: u16,
}

#[uniffi::export]
impl LumaApi {
    #[uniffi::constructor]
    pub fn new(config: FfiConfig) -> Result<Arc<Self>, FfiError> {
        let _ = tracing_subscriber::fmt().with_env_filter("info").try_init();

        let runtime = Runtime::new().map_err(|e| FfiError::Failed { message: e.to_string() })?;
        let storage = Storage::open(&config.db_path).map_err(FfiError::from)?;

        let base_engine_config = EngineConfig { home_id: config.home_id.clone(), db_path: config.db_path.clone(), ..Default::default() };
        let controller = Arc::new(EngineController::new(base_engine_config));

        // Primary comms path: the phone IS the broker.
        let broker_config = luma_broker::BrokerConfig {
            bind_addr: config.broker_bind_addr.clone(),
            port: config.broker_port,
            require_auth: config.broker_require_auth,
            home_secret: config.broker_home_secret.clone().unwrap_or_default().into_bytes(),
        };
        let broker = Arc::new(BrokerEngine::new(broker_config, storage.clone()));
        controller.register(broker.clone());

        let automation_engine = Arc::new(AutomationEngine::new(storage.clone()));
        controller.register(automation_engine);

        // Optional: bridge to a remote broker once internet is available.
        if config.enable_cloud_bridge {
            if let Some(host) = config.cloud_mqtt_host.clone() {
                let bridge_config = EngineConfig {
                    home_id: config.home_id.clone(),
                    db_path: config.db_path.clone(),
                    mqtt_host: host,
                    mqtt_port: config.cloud_mqtt_port.unwrap_or(8883),
                    mqtt_client_id: config.cloud_mqtt_client_id.clone().unwrap_or_else(|| format!("{}-bridge", config.home_id)),
                    mqtt_username: config.cloud_mqtt_username.clone(),
                    mqtt_password: config.cloud_mqtt_password.clone(),
                    mqtt_use_tls: config.cloud_mqtt_use_tls,
                };
                let bridge = Arc::new(MqttEngine::new(bridge_config, storage.clone()));
                controller.register(bridge);
            } else {
                tracing::warn!("enable_cloud_bridge was true but cloud_mqtt_host is unset; skipping bridge");
            }
        }

        Ok(Arc::new(Self { runtime, controller, storage, broker, broker_port: config.broker_port }))
    }

    // ---- Layer 2 Public API (mirrors design doc section 15) ----

    pub fn start_engine(&self) -> Result<(), FfiError> {
        self.runtime.block_on(self.controller.start()).map_err(FfiError::from)
    }

    pub fn stop_engine(&self) -> Result<(), FfiError> {
        self.runtime.block_on(self.controller.stop()).map_err(FfiError::from)
    }

    pub fn engine_state(&self) -> String {
        format!("{:?}", self.controller.state())
    }

    /// Runs UDP-broadcast and mDNS discovery in parallel for `timeout_ms`,
    /// persisting anything found. BLE discovery is handled natively on the
    /// Android/iOS side (radios aren't reachable from sandboxed Rust) and
    /// gets fed in via `report_discovered_device`. In practice a device
    /// simply *connecting* to the broker is itself a discovery signal too —
    /// no scan required for devices already provisioned with the broker's address.
    pub fn scan_devices(&self, timeout_ms: u32) -> Result<Vec<FfiDevice>, FfiError> {
        let storage = self.storage.clone();
        let bus = self.controller.bus.clone();
        self.runtime.block_on(async move {
            tokio::join!(luma_discovery::udp_probe(timeout_ms), luma_discovery::mdns_probe(timeout_ms, &storage, &bus));
        });
        self.get_devices()
    }

    /// Called by native (Kotlin/Swift) BLE scan code to hand a discovered
    /// device over to the Rust core for provisioning.
    pub fn report_discovered_device(&self, device_id: String, name: String, mac_address: String) -> Result<(), FfiError> {
        let mut device = Device::new(name, mac_address, "esp32");
        device.id = device_id;
        self.storage.upsert_device(&device).map_err(FfiError::from)?;
        self.controller.bus.publish(LumaEvent::DeviceDiscovered {
            device_id: device.id,
            name: device.name,
            mac_address: device.mac_address,
        });
        Ok(())
    }

    /// Manual status override (e.g. user marks a device as ignored). The
    /// broker itself flips this automatically based on real MQTT CONNECT/
    /// disconnect events — you don't need to call this for normal operation.
    pub fn connect_device(&self, device_id: String) -> Result<(), FfiError> {
        self.storage.set_device_status(&device_id, luma_core::models::DeviceStatus::Online).map_err(FfiError::from)
    }

    pub fn disconnect_device(&self, device_id: String) -> Result<(), FfiError> {
        self.storage.set_device_status(&device_id, luma_core::models::DeviceStatus::Offline).map_err(FfiError::from)
    }

    /// Publish an arbitrary command to a device. `desired_state_json` should
    /// be a JSON object, e.g. `{"power": true, "brightness": 80}`. Prefer
    /// `send_command` for the standard vocabulary — use this for anything
    /// custom firmware needs beyond it.
    pub fn publish_message(&self, device_id: String, desired_state_json: String) -> Result<(), FfiError> {
        let value: serde_json::Value =
            serde_json::from_str(&desired_state_json).map_err(|e| FfiError::Failed { message: e.to_string() })?;
        self.controller.bus.publish(LumaEvent::DeviceCommand { device_id, desired_state: value });
        Ok(())
    }

    /// Type-safe control using the standard command vocabulary (design doc
    /// section 8: ON/OFF/Toggle/Brightness/RGB/FanSpeed/ServoAngle/Restart/
    /// FactoryReset). Delivered over the embedded broker's `device/{id}/command`
    /// topic — and mirrored to the cloud bridge, if enabled, for remote visibility.
    pub fn send_command(&self, device_id: String, command: FfiDeviceCommand) -> Result<(), FfiError> {
        let dc: luma_core::models::DeviceCommand = command.into();
        self.controller.bus.publish(LumaEvent::DeviceCommand { device_id, desired_state: dc.to_json() });
        Ok(())
    }

    /// Subscribing from the UI's perspective just means "start caring about this
    /// device's updates" — the engine already subscribes to every device topic
    /// under the hood, so this just guarantees a row exists to receive updates.
    pub fn subscribe_topic(&self, device_id: String) -> Result<(), FfiError> {
        if self.storage.get_device(&device_id).is_err() {
            let device = Device::new(device_id.clone(), device_id.clone(), "unknown");
            self.storage.upsert_device(&device).map_err(FfiError::from)?;
        }
        Ok(())
    }

    pub fn get_devices(&self) -> Result<Vec<FfiDevice>, FfiError> {
        Ok(self.storage.list_devices().map_err(FfiError::from)?.into_iter().map(FfiDevice::from).collect())
    }

    pub fn get_device(&self, device_id: String) -> Result<FfiDevice, FfiError> {
        Ok(self.storage.get_device(&device_id).map_err(FfiError::from)?.into())
    }

    /// Live snapshot from the broker's Client Manager — connected ESP32s,
    /// their subscriptions, session type, and last-known RSSI.
    pub fn get_connected_clients(&self) -> Vec<FfiMqttClient> {
        self.broker.client_snapshot().into_iter().map(FfiMqttClient::from).collect()
    }

    /// Backs the "MQTT Monitor" screen (design doc section 10).
    pub fn get_mqtt_monitor(&self) -> FfiBrokerStats {
        FfiBrokerStats {
            port: self.broker_port,
            connected_clients: self.broker.connected_count() as u32,
            max_clients: luma_broker::MAX_CLIENTS as u32,
            retained_messages: self.broker.retained_count() as u32,
            known_topics: self.broker.topic_snapshot(),
        }
    }

    pub fn create_automation(&self, spec: FfiAutomationSpec) -> Result<String, FfiError> {
        let trigger_value: serde_json::Value =
            serde_json::from_str(&spec.trigger_value_json).unwrap_or(serde_json::Value::Null);

        let conditions = spec
            .condition_specs
            .iter()
            .filter_map(|s| parse_condition(s))
            .collect::<Vec<_>>();
        let actions = spec.action_specs.iter().filter_map(|s| parse_action(s)).collect::<Vec<_>>();

        let automation = Automation {
            id: uuid::Uuid::new_v4().to_string(),
            name: spec.name,
            enabled: true,
            trigger: TriggerKind::DeviceState {
                device_id: spec.trigger_device_id,
                path: spec.trigger_path,
                op: spec.trigger_op.into(),
                value: trigger_value,
            },
            conditions,
            actions,
            created_at: chrono::Utc::now(),
        };
        self.storage.upsert_automation(&automation).map_err(FfiError::from)?;
        Ok(automation.id)
    }

    pub fn run_scene(&self, scene_id: String) -> Result<(), FfiError> {
        let scene = self.storage.get_scene(&scene_id).map_err(FfiError::from)?;
        luma_automation::run_scene(&self.controller.bus, &scene);
        Ok(())
    }

    pub fn create_scene(&self, name: String, action_specs: Vec<String>) -> Result<String, FfiError> {
        let actions = action_specs.iter().filter_map(|s| parse_action(s)).collect::<Vec<_>>();
        let scene = Scene { id: uuid::Uuid::new_v4().to_string(), name, actions };
        self.storage.upsert_scene(&scene).map_err(FfiError::from)?;
        Ok(scene.id)
    }

    /// Kicks off an OTA push to a device. The actual transfer/verification is
    /// handled by the OTA engine (delivered as a follow-up module); for now
    /// this records the intent and emits progress events so the UI wiring can
    /// be built against a stable event contract immediately.
    pub fn update_firmware(&self, device_id: String, firmware_url: String) -> Result<(), FfiError> {
        self.controller.bus.publish(LumaEvent::OtaProgress { device_id: device_id.clone(), percent: 0 });
        self.storage
            .add_log(&LogEntry {
                id: uuid::Uuid::new_v4().to_string(),
                level: "info".into(),
                source: "ota".into(),
                message: format!("OTA requested for {device_id} from {firmware_url}"),
                timestamp: chrono::Utc::now(),
            })
            .map_err(FfiError::from)?;
        Ok(())
    }

    pub fn get_logs(&self, limit: u32) -> Result<Vec<FfiLogEntry>, FfiError> {
        Ok(self.storage.recent_logs(limit).map_err(FfiError::from)?.into_iter().map(FfiLogEntry::from).collect())
    }

    /// Cloud sync hook — flushes the local outbox and reports status via events.
    /// A no-op if the cloud bridge isn't enabled; the local broker keeps
    /// working regardless, per the offline-first requirement.
    pub fn sync_cloud(&self) -> Result<(), FfiError> {
        self.controller.bus.publish(LumaEvent::SyncStarted);
        let count = self.storage.drain_outbox(1000).map(|v| v.len() as u32).unwrap_or(0);
        self.controller.bus.publish(LumaEvent::SyncCompleted { synced_items: count });
        Ok(())
    }
}

fn parse_condition(spec: &str) -> Option<Condition> {
    let parts: Vec<&str> = spec.splitn(4, '|').collect();
    if parts.len() != 4 {
        return None;
    }
    let op = match parts[2] {
        "eq" => CompareOp::Eq,
        "neq" => CompareOp::Neq,
        "gt" => CompareOp::Gt,
        "gte" => CompareOp::Gte,
        "lt" => CompareOp::Lt,
        "lte" => CompareOp::Lte,
        _ => return None,
    };
    Some(Condition {
        device_id: parts[0].to_string(),
        path: parts[1].to_string(),
        op,
        value: serde_json::from_str(parts[3]).unwrap_or(serde_json::Value::Null),
    })
}

fn parse_action(spec: &str) -> Option<Action> {
    let parts: Vec<&str> = spec.splitn(2, '|').collect();
    if parts.len() != 2 {
        return None;
    }
    Some(Action {
        device_id: parts[0].to_string(),
        set_state: serde_json::from_str(parts[1]).unwrap_or(serde_json::Value::Null),
        delay_ms: None,
    })
}

mod luma_discovery {
    use luma_core::event_bus::{EventBus, LumaEvent};
    use luma_storage::Storage;
    use mdns_sd::{ServiceDaemon, ServiceEvent};
    use tokio::net::UdpSocket;
    use tokio::time::{timeout, Duration, Instant};

    /// Sends a single UDP broadcast probe on port 47893 that LUMA-flashed
    /// ESP32s listen for, then drains any immediate replies for the given
    /// window (design doc section 5: "UDP Broadcast").
    pub async fn udp_probe(timeout_ms: u32) {
        let Ok(socket) = UdpSocket::bind("0.0.0.0:0").await else { return };
        if socket.set_broadcast(true).is_err() {
            return;
        }
        let _ = socket.send_to(b"LUMA_DISCOVER", "255.255.255.255:47893").await;
        let mut buf = [0u8; 512];
        let _ = timeout(Duration::from_millis(timeout_ms as u64), socket.recv_from(&mut buf)).await;
    }

    /// Browses `_luma._tcp.local.` for the given window and persists every
    /// resolved ESP32 (design doc section 5: "mDNS"). Expects TXT keys `mac`,
    /// `name`, `type`, `fw` on the advertised service, matching what the
    /// device advertises per section 5's discovery payload.
    pub async fn mdns_probe(timeout_ms: u32, storage: &Storage, bus: &EventBus) {
        let Ok(daemon) = ServiceDaemon::new() else { return };
        let service_type = "_luma._tcp.local.";
        let Ok(receiver) = daemon.browse(service_type) else { return };
        let deadline = Instant::now() + Duration::from_millis(timeout_ms as u64);

        loop {
            let remaining = deadline.saturating_duration_since(Instant::now());
            if remaining.is_zero() {
                break;
            }
            let event = match timeout(remaining, receiver.recv_async()).await {
                Ok(Ok(ev)) => ev,
                _ => break,
            };
            if let ServiceEvent::ServiceResolved(info) = event {
                let mac = info.get_property_val_str("mac").unwrap_or_else(|| info.get_hostname()).to_string();
                let name = info.get_property_val_str("name").unwrap_or_else(|| info.get_hostname()).to_string();
                let device_type = info.get_property_val_str("type").unwrap_or("esp32").to_string();
                let fw = info.get_property_val_str("fw").unwrap_or("unknown").to_string();
                let ip = info.get_addresses_v4().iter().next().map(|a| a.to_string());
                let device_id = mac.replace(':', "").to_lowercase();

                let mut device =
                    storage.get_device(&device_id).unwrap_or_else(|_| luma_core::models::Device::new(name.clone(), mac.clone(), device_type.clone()));
                device.id = device_id.clone();
                device.name = name.clone();
                device.mac_address = mac.clone();
                device.device_type = device_type.clone();
                device.firmware_version = fw;
                device.ip_address = ip;
                let _ = storage.upsert_device(&device);

                bus.publish(LumaEvent::DeviceDiscovered { device_id, name, mac_address: mac });
            }
        }

        let _ = daemon.stop_browse(service_type);
        let _ = daemon.shutdown();
    }
}
