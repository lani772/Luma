pub mod client;
pub mod inflight;
pub mod protocol;
pub mod topics;

pub use client::{ClientHandle, ClientManager, ClientSnapshot, ClientStatus, MAX_CLIENTS};
pub use protocol::BrokerState;

use async_trait::async_trait;
use bytes::Bytes;
use chrono::Utc;
use luma_core::engine::Engine;
use luma_core::error::{LumaError, LumaResult};
use luma_core::event_bus::{EventBus, LumaEvent};
use luma_storage::Storage;
use mqttbytes::v4::Packet;
use mqttbytes::QoS;
use std::sync::Arc;
use std::time::Duration;
use tokio::net::TcpListener;
use tokio::sync::{watch, Notify};

#[derive(Clone)]
pub struct BrokerConfig {
    /// Usually "0.0.0.0" so it's reachable over the phone's hotspot or the
    /// shared WiFi router — see design doc section 4 "Communication Modes".
    pub bind_addr: String,
    pub port: u16,
    pub require_auth: bool,
    pub home_secret: Vec<u8>,
}

impl Default for BrokerConfig {
    fn default() -> Self {
        Self { bind_addr: "0.0.0.0".into(), port: 1883, require_auth: false, home_secret: Vec::new() }
    }
}

/// The embedded MQTT broker itself — this is what makes the phone the
/// server instead of a client of one, per the doc's core requirement.
/// Implements `Engine` so it starts/stops alongside every other module.
pub struct BrokerEngine {
    config: BrokerConfig,
    storage: Storage,
    state: Arc<BrokerState>,
    shutdown_tx: watch::Sender<bool>,
}

impl BrokerEngine {
    pub fn new(config: BrokerConfig, storage: Storage) -> Self {
        let (shutdown_tx, _) = watch::channel(false);
        Self { config, storage, state: Arc::new(BrokerState::default()), shutdown_tx }
    }

    pub fn client_snapshot(&self) -> Vec<ClientSnapshot> {
        self.state.clients.snapshot()
    }

    pub fn topic_snapshot(&self) -> Vec<String> {
        self.state.topics.snapshot()
    }

    pub fn retained_count(&self) -> usize {
        self.state.retained.read().len()
    }

    pub fn connected_count(&self) -> usize {
        self.state.clients.connected_count()
    }
}

#[async_trait]
impl Engine for BrokerEngine {
    fn name(&self) -> &'static str {
        "mqtt-broker"
    }

    async fn start(&self, bus: EventBus) -> LumaResult<()> {
        // Rehydrate persistent sessions from a previous run so commands sent
        // before the ESP32's first post-restart reconnect still get queued
        // instead of silently vanishing.
        if let Ok(rows) = self.storage.list_persistent_broker_clients() {
            for (client_id, mac, subs) in rows {
                let handle = ClientHandle {
                    client_id: client_id.clone(),
                    mac_address: mac,
                    ip_address: String::new(),
                    connected_at: Utc::now(),
                    last_seen: Utc::now(),
                    clean_session: false,
                    status: ClientStatus::Disconnected,
                    rssi: None,
                    subscriptions: subs,
                    last_will: None,
                    sender: None,
                    next_pkid: 0,
                    close_notify: Arc::new(Notify::new()),
                };
                self.state.clients.connect(handle);
            }
        }

        let listener = TcpListener::bind((self.config.bind_addr.as_str(), self.config.port))
            .await
            .map_err(|e| LumaError::Mqtt(format!("bind {}:{} failed: {e}", self.config.bind_addr, self.config.port)))?;
        tracing::info!(addr = %self.config.bind_addr, port = self.config.port, "mqtt broker listening");

        let auth = protocol::AuthConfig { require_auth: self.config.require_auth, home_secret: self.config.home_secret.clone() };

        // Accept loop.
        {
            let state = self.state.clone();
            let storage = self.storage.clone();
            let bus = bus.clone();
            let mut shutdown_rx = self.shutdown_tx.subscribe();
            tokio::spawn(async move {
                loop {
                    tokio::select! {
                        _ = shutdown_rx.changed() => break,
                        accepted = listener.accept() => match accepted {
                            Ok((stream, addr)) => {
                                let state = state.clone();
                                let storage = storage.clone();
                                let bus = bus.clone();
                                let auth = auth.clone();
                                tokio::spawn(async move {
                                    if let Err(e) = protocol::handle_connection(stream, addr, state, storage, bus, auth).await {
                                        tracing::debug!(error = %e, "broker connection ended");
                                    }
                                });
                            }
                            Err(e) => tracing::warn!(error = %e, "broker accept error"),
                        }
                    }
                }
            });
        }

        // Bus bridge: turn DeviceCommand events (from automation or the FFI
        // layer) into an actual publish to the addressed device's command topic.
        {
            let state = self.state.clone();
            let storage = self.storage.clone();
            let bus_inner = bus.clone();
            let mut rx = bus.subscribe();
            let mut shutdown_rx = self.shutdown_tx.subscribe();
            tokio::spawn(async move {
                loop {
                    tokio::select! {
                        _ = shutdown_rx.changed() => break,
                        ev = rx.recv() => match ev {
                            Ok(LumaEvent::DeviceCommand { device_id, desired_state }) => {
                                let topic = topics::conventions::command(&device_id);
                                let payload = Bytes::from(desired_state.to_string().into_bytes());
                                protocol::route_publish(&state, &storage, &bus_inner, &topic, payload, QoS::AtLeastOnce, false, None).await;
                            }
                            Ok(_) => {}
                            Err(tokio::sync::broadcast::error::RecvError::Lagged(_)) => continue,
                            Err(_) => break,
                        }
                    }
                }
            });
        }

        // Retry sweep for unacked QoS1 deliveries (design goal 9: "Retry on failure").
        {
            let state = self.state.clone();
            let mut shutdown_rx = self.shutdown_tx.subscribe();
            tokio::spawn(async move {
                let mut interval = tokio::time::interval(Duration::from_secs(2));
                loop {
                    tokio::select! {
                        _ = shutdown_rx.changed() => break,
                        _ = interval.tick() => {
                            for (client_id, publish) in state.inflight.due_for_retry() {
                                if let Some(sender) = state.clients.get_sender(&client_id) {
                                    let _ = sender.send(Packet::Publish(publish)).await;
                                }
                            }
                        }
                    }
                }
            });
        }

        bus.publish(LumaEvent::BrokerStarted { port: self.config.port });
        Ok(())
    }

    async fn stop(&self) -> LumaResult<()> {
        let _ = self.shutdown_tx.send(true);
        Ok(())
    }
}
