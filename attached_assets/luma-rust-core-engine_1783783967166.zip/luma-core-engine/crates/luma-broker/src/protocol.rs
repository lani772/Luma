use crate::client::{ClientHandle, ClientStatus};
use crate::inflight::InFlightTracker;
use crate::topics::{topic_matches, TopicManager};
use bytes::{Bytes, BytesMut};
use chrono::Utc;
use luma_core::event_bus::{EventBus, LumaEvent};
use luma_core::models::DeviceStatus;
use luma_storage::Storage;
use mqttbytes::v4::{
    ConnAck, ConnectReturnCode, Disconnect as DisconnectMsg, Packet, PingReq, PingResp, Publish,
    SubAck, SubscribeReasonCode, UnsubAck,
};
use mqttbytes::QoS;
use parking_lot::RwLock;
use std::collections::{HashMap, HashSet};
use std::net::SocketAddr;
use std::sync::Arc;
use std::time::Duration;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::tcp::{OwnedReadHalf, OwnedWriteHalf};
use tokio::net::TcpStream;
use tokio::sync::{mpsc, Notify};

const MAX_PACKET_SIZE: usize = 256 * 1024;
const CONNECT_TIMEOUT: Duration = Duration::from_secs(10);

/// Everything the whole broker shares across connections.
pub struct BrokerState {
    pub clients: crate::client::ClientManager,
    pub topics: TopicManager,
    pub retained: RwLock<HashMap<String, Publish>>,
    pub inflight: InFlightTracker,
}

impl Default for BrokerState {
    fn default() -> Self {
        Self {
            clients: Default::default(),
            topics: Default::default(),
            retained: RwLock::new(HashMap::new()),
            inflight: Default::default(),
        }
    }
}

#[derive(Clone)]
pub struct AuthConfig {
    pub require_auth: bool,
    pub home_secret: Vec<u8>,
}

enum ExitReason {
    /// A newer connection with the same client_id took over — this socket's
    /// state has already been superseded, so no LWT/offline bookkeeping here.
    TakenOver,
    /// Client sent DISCONNECT — no LWT.
    Graceful,
    /// Socket error, EOF, or keep-alive timeout — fires LWT if one is set.
    Ungraceful,
}

pub async fn handle_connection(
    stream: TcpStream,
    addr: SocketAddr,
    state: Arc<BrokerState>,
    storage: Storage,
    bus: EventBus,
    auth: AuthConfig,
) -> Result<(), String> {
    stream.set_nodelay(true).ok();
    let (mut read_half, write_half) = stream.into_split();
    let mut buf = BytesMut::with_capacity(1024);

    let connect = match tokio::time::timeout(CONNECT_TIMEOUT, read_next_packet(&mut read_half, &mut buf)).await {
        Ok(Some(Packet::Connect(c))) => c,
        _ => return Err(format!("{addr}: no valid CONNECT within timeout")),
    };
    let client_id = connect.client_id.clone();

    // Capacity check (max 5 simultaneously connected devices).
    if let Err(e) = state.clients.require_capacity(&client_id) {
        let (tx, rx) = mpsc::channel(4);
        tokio::spawn(writer_task(write_half, rx));
        let _ = tx.send(Packet::ConnAck(ConnAck::new(ConnectReturnCode::ServiceUnavailable, false))).await;
        return Err(e.to_string());
    }

    // Optional device-token auth (off by default — local network is trusted
    // by design per the doc's "Local-only communication by default").
    if auth.require_auth {
        let ok = connect
            .login
            .as_ref()
            .map(|login| luma_security::verify_device_token(&auth.home_secret, &login.password, Utc::now().timestamp()))
            .unwrap_or(false);
        if !ok {
            let (tx, rx) = mpsc::channel(4);
            tokio::spawn(writer_task(write_half, rx));
            let _ = tx.send(Packet::ConnAck(ConnAck::new(ConnectReturnCode::NotAuthorized, false))).await;
            return Err(format!("{client_id}: failed device-token auth"));
        }
    }

    let (tx, rx) = mpsc::channel::<Packet>(128);
    tokio::spawn(writer_task(write_half, rx));

    let stored_subs = storage.get_broker_client_subscriptions(&client_id).unwrap_or_default();
    let session_present = !connect.clean_session && !stored_subs.is_empty();

    let close_notify = Arc::new(Notify::new());
    let handle = ClientHandle {
        client_id: client_id.clone(),
        mac_address: Some(client_id.clone()),
        ip_address: addr.ip().to_string(),
        connected_at: Utc::now(),
        last_seen: Utc::now(),
        clean_session: connect.clean_session,
        status: ClientStatus::Connected,
        rssi: None,
        subscriptions: if session_present { stored_subs } else { Vec::new() },
        last_will: connect.last_will.clone(),
        sender: Some(tx.clone()),
        next_pkid: 0,
        close_notify: close_notify.clone(),
    };
    // connect() internally notifies+drops any prior connection for this client_id.
    state.clients.connect(handle);

    let _ = tx.send(Packet::ConnAck(ConnAck::new(ConnectReturnCode::Success, session_present))).await;

    let mut device = luma_core::models::Device::new(client_id.clone(), client_id.clone(), "esp32");
    device.id = client_id.clone();
    device.ip_address = Some(addr.ip().to_string());
    device.status = DeviceStatus::Online;
    let _ = storage.upsert_device(&device);
    let _ = storage.set_device_status(&client_id, DeviceStatus::Online);
    bus.publish(LumaEvent::BrokerClientConnected {
        client_id: client_id.clone(),
        ip_address: addr.ip().to_string(),
        clean_session: connect.clean_session,
    });
    bus.publish(LumaEvent::DeviceOnline { device_id: client_id.clone() });

    // Flush anything that piled up while this persistent-session client was offline.
    if session_present {
        if let Ok(queued) = storage.drain_session_messages(&client_id, 200) {
            for (row_id, topic, payload, qos_num) in queued {
                let qos = qos_from_i32(qos_num);
                let mut p = Publish::from_bytes(topic, qos, Bytes::from(payload));
                if qos != QoS::AtMostOnce {
                    if let Some(pkid) = state.clients.alloc_pkid(&client_id) {
                        p.pkid = pkid;
                    }
                }
                if tx.send(Packet::Publish(p.clone())).await.is_ok() {
                    if qos != QoS::AtMostOnce {
                        state.inflight.track(&client_id, p);
                    }
                    let _ = storage.remove_session_message(&row_id);
                }
            }
        }
    }

    let keep_alive = Duration::from_secs((connect.keep_alive.max(15) as u64) + connect.keep_alive.max(15) as u64 / 2);
    let exit_reason = connection_loop(&mut read_half, &mut buf, &state, &storage, &bus, &client_id, &tx, &close_notify, keep_alive).await;

    finalize_connection(&state, &storage, &bus, &client_id, connect.clean_session, exit_reason).await;
    Ok(())
}

#[allow(clippy::too_many_arguments)]
async fn connection_loop(
    read_half: &mut OwnedReadHalf,
    buf: &mut BytesMut,
    state: &Arc<BrokerState>,
    storage: &Storage,
    bus: &EventBus,
    client_id: &str,
    tx: &mpsc::Sender<Packet>,
    close_notify: &Arc<Notify>,
    keep_alive: Duration,
) -> ExitReason {
    loop {
        let read_fut = tokio::time::timeout(keep_alive, read_next_packet(read_half, buf));
        tokio::select! {
            _ = close_notify.notified() => return ExitReason::TakenOver,
            result = read_fut => {
                let packet = match result {
                    Ok(Some(p)) => p,
                    Ok(None) => return ExitReason::Ungraceful,   // EOF / socket error
                    Err(_) => return ExitReason::Ungraceful,      // keep-alive timeout
                };
                match packet {
                    Packet::Publish(p) => {
                        state.clients.touch(client_id);
                        if p.qos != QoS::AtMostOnce {
                            let _ = tx.send(Packet::PubAck(mqttbytes::v4::PubAck::new(p.pkid))).await;
                        }
                        let effective_qos = if p.qos == QoS::ExactlyOnce { QoS::AtLeastOnce } else { p.qos };
                        route_publish(state, storage, bus, &p.topic, p.payload.clone(), effective_qos, p.retain, Some(client_id)).await;
                    }
                    Packet::Subscribe(s) => {
                        state.clients.touch(client_id);
                        let mut codes = Vec::with_capacity(s.filters.len());
                        let mut added = Vec::with_capacity(s.filters.len());
                        for f in &s.filters {
                            if !mqttbytes::valid_filter(&f.path) {
                                codes.push(SubscribeReasonCode::Failure);
                                continue;
                            }
                            let granted = if f.qos == QoS::ExactlyOnce { QoS::AtLeastOnce } else { f.qos };
                            codes.push(SubscribeReasonCode::Success(granted));
                            added.push(f.path.clone());
                        }
                        state.clients.set_subscriptions(client_id, added.clone());
                        let _ = tx.send(Packet::SubAck(SubAck::new(s.pkid, codes))).await;

                        let merged = state.clients.snapshot().into_iter().find(|c| c.client_id == client_id).map(|c| c.subscriptions).unwrap_or(added);
                        let _ = storage.upsert_broker_client(client_id, Some(client_id), None, false, &merged, None);

                        replay_retained(state, client_id, tx, &merged).await;
                    }
                    Packet::Unsubscribe(u) => {
                        state.clients.touch(client_id);
                        state.clients.remove_subscriptions(client_id, &u.topics);
                        let _ = tx.send(Packet::UnsubAck(UnsubAck::new(u.pkid))).await;
                    }
                    Packet::PubAck(a) => {
                        state.inflight.ack(client_id, a.pkid);
                    }
                    Packet::PingReq => {
                        state.clients.touch(client_id);
                        let _ = tx.send(Packet::PingResp).await;
                    }
                    Packet::Disconnect => return ExitReason::Graceful,
                    _ => { /* PubRec/PubRel/PubComp: QoS2 unsupported by design, ignored */ }
                }
            }
        }
    }
}

async fn finalize_connection(
    state: &Arc<BrokerState>,
    storage: &Storage,
    bus: &EventBus,
    client_id: &str,
    clean_session: bool,
    reason: ExitReason,
) {
    if matches!(reason, ExitReason::TakenOver) {
        return;
    }

    if let ExitReason::Ungraceful = reason {
        if let Some(will) = state.clients.last_will(client_id) {
            tracing::info!(client_id, topic = %will.topic, "firing last will");
            route_publish(state, storage, bus, &will.topic, will.message.clone(), will.qos, will.retain, None).await;
        }
    }

    state.inflight.drop_client(client_id);
    if clean_session {
        state.clients.remove(client_id);
        let _ = storage.clear_session_messages(client_id);
    } else {
        state.clients.mark_disconnected(client_id);
    }

    let _ = storage.set_device_status(client_id, DeviceStatus::Offline);
    bus.publish(LumaEvent::DeviceOffline { device_id: client_id.to_string() });
    bus.publish(LumaEvent::BrokerClientDisconnected {
        client_id: client_id.to_string(),
        graceful: matches!(reason, ExitReason::Graceful),
    });
}

async fn replay_retained(state: &Arc<BrokerState>, client_id: &str, tx: &mpsc::Sender<Packet>, filters: &[String]) {
    let matching: Vec<Publish> = {
        let retained = state.retained.read();
        retained.iter().filter(|(topic, _)| filters.iter().any(|f| topic_matches(topic, f))).map(|(_, p)| p.clone()).collect()
    };
    for mut p in matching {
        p.retain = true;
        // These are clones of the stored retained message, which carries
        // whatever pkid it had when first published (often 0). QoS>=1
        // requires a nonzero pkid per spec — mqttbytes correctly rejects
        // pkid=0 at encode time — so each subscriber needs its own fresh id.
        if p.qos != QoS::AtMostOnce {
            if let Some(pkid) = state.clients.alloc_pkid(client_id) {
                p.pkid = pkid;
            }
        }
        if tx.send(Packet::Publish(p.clone())).await.is_ok() && p.qos != QoS::AtMostOnce {
            state.inflight.track(client_id, p);
        }
    }
}

/// Routes one publish to every live matching subscriber, queues it for
/// matching offline persistent-session clients, updates the retained-message
/// store, and bridges device/{id}/data|status traffic into the event bus so
/// the automation engine and storage shadow stay in sync. Also used to fire
/// Last Will messages, which follow the exact same fan-out path.
pub async fn route_publish(
    state: &Arc<BrokerState>,
    storage: &Storage,
    bus: &EventBus,
    topic: &str,
    payload: Bytes,
    qos: QoS,
    retain: bool,
    exclude_client: Option<&str>,
) {
    state.topics.observe(topic);

    if retain {
        if payload.is_empty() {
            state.retained.write().remove(topic);
        } else {
            let mut p = Publish::from_bytes(topic, qos, payload.clone());
            p.retain = true;
            state.retained.write().insert(topic.to_string(), p);
        }
    }

    let mut delivered_to: HashSet<String> = HashSet::new();
    for (cid, sender) in state.clients.matching_senders(topic) {
        if Some(cid.as_str()) == exclude_client {
            continue;
        }
        delivered_to.insert(cid.clone());
        let mut out = Publish::from_bytes(topic, qos, payload.clone());
        if qos != QoS::AtMostOnce {
            if let Some(pkid) = state.clients.alloc_pkid(&cid) {
                out.pkid = pkid;
            }
        }
        if sender.send(Packet::Publish(out.clone())).await.is_ok() && qos != QoS::AtMostOnce {
            state.inflight.track(&cid, out);
        }
    }

    if qos != QoS::AtMostOnce {
        for snap in state.clients.snapshot() {
            if snap.connected || snap.clean_session || delivered_to.contains(&snap.client_id) {
                continue;
            }
            if Some(snap.client_id.as_str()) == exclude_client {
                continue;
            }
            if snap.subscriptions.iter().any(|f| topic_matches(topic, f)) {
                let _ = storage.enqueue_session_message(&snap.client_id, topic, &payload, qos as i32);
            }
        }
    }

    handle_device_topic(state, topic, &payload, storage, bus);
}

fn handle_device_topic(state: &Arc<BrokerState>, topic: &str, payload: &Bytes, storage: &Storage, bus: &EventBus) {
    let Some(rest) = topic.strip_prefix("device/") else { return };
    let parts: Vec<&str> = rest.splitn(2, '/').collect();
    if parts.len() != 2 {
        return;
    }
    let device_id = parts[0];
    let kind = parts[1];
    let text = String::from_utf8_lossy(payload).to_string();
    let value: serde_json::Value = serde_json::from_str(&text).unwrap_or(serde_json::Value::String(text.clone()));

    match kind {
        "data" => {
            if let Ok(device) = storage.merge_reported_state(device_id, &value) {
                bus.publish(LumaEvent::DeviceStateChanged { device });
            }
            let _ = storage.record_telemetry(device_id, "data", &value);
            bus.publish(LumaEvent::DeviceMessageReceived {
                device_id: device_id.to_string(),
                topic: topic.to_string(),
                payload: value,
            });
        }
        "status" => {
            if let Some(obj) = value.as_object() {
                if let Some(rssi) = obj.get("rssi").and_then(|v| v.as_i64()) {
                    state.clients.update_rssi(device_id, rssi as i32);
                }
                if let Some(battery) = obj.get("battery") {
                    let _ = storage.record_telemetry(device_id, "battery", battery);
                }
            }
        }
        _ => {}
    }
}

async fn writer_task(mut write_half: OwnedWriteHalf, mut rx: mpsc::Receiver<Packet>) {
    let mut out = BytesMut::with_capacity(512);
    while let Some(packet) = rx.recv().await {
        out.clear();
        if write_packet(&packet, &mut out).is_ok() && write_half.write_all(&out).await.is_err() {
            break;
        }
    }
    let _ = write_half.shutdown().await;
}

fn write_packet(packet: &Packet, buf: &mut BytesMut) -> Result<(), mqttbytes::Error> {
    match packet {
        Packet::ConnAck(p) => p.write(buf).map(|_| ()),
        Packet::Publish(p) => p.write(buf).map(|_| ()),
        Packet::PubAck(p) => p.write(buf).map(|_| ()),
        Packet::PubRec(p) => p.write(buf).map(|_| ()),
        Packet::PubRel(p) => p.write(buf).map(|_| ()),
        Packet::PubComp(p) => p.write(buf).map(|_| ()),
        Packet::SubAck(p) => p.write(buf).map(|_| ()),
        Packet::UnsubAck(p) => p.write(buf).map(|_| ()),
        Packet::PingReq => PingReq.write(buf).map(|_| ()),
        Packet::PingResp => PingResp.write(buf).map(|_| ()),
        Packet::Disconnect => DisconnectMsg.write(buf).map(|_| ()),
        Packet::Connect(_) | Packet::Subscribe(_) | Packet::Unsubscribe(_) => Ok(()), // broker never sends these
    }
}

async fn read_next_packet(read_half: &mut OwnedReadHalf, buf: &mut BytesMut) -> Option<Packet> {
    loop {
        match mqttbytes::v4::read(buf, MAX_PACKET_SIZE) {
            Ok(packet) => return Some(packet),
            Err(mqttbytes::Error::InsufficientBytes(_)) => {
                let mut chunk = [0u8; 2048];
                match read_half.read(&mut chunk).await {
                    Ok(0) => return None,
                    Ok(n) => buf.extend_from_slice(&chunk[..n]),
                    Err(_) => return None,
                }
            }
            Err(e) => {
                tracing::debug!(error = ?e, "malformed MQTT packet, dropping connection");
                return None;
            }
        }
    }
}

fn qos_from_i32(v: i32) -> QoS {
    match v {
        0 => QoS::AtMostOnce,
        2 => QoS::ExactlyOnce,
        _ => QoS::AtLeastOnce,
    }
}
