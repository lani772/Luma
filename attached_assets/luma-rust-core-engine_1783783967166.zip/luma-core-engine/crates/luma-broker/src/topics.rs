use parking_lot::RwLock;
use std::collections::HashSet;

pub use mqttbytes::{has_wildcards, matches as topic_matches, valid_filter, valid_topic};

/// Suggested topic conventions (design doc section 3):
///   home/{room}/{device}         e.g. home/livingroom/light1, home/all
///   device/{mac}/command
///   device/{mac}/status
///   device/{mac}/config
///   device/{mac}/update
///   device/{mac}/data
/// The broker itself is convention-agnostic — routing is pure wildcard
/// matching via `topic_matches` — these are just the names LUMA firmware and
/// the mobile UI agree to use.
pub mod conventions {
    pub fn command(mac: &str) -> String {
        format!("device/{mac}/command")
    }
    pub fn status(mac: &str) -> String {
        format!("device/{mac}/status")
    }
    pub fn config(mac: &str) -> String {
        format!("device/{mac}/config")
    }
    pub fn update(mac: &str) -> String {
        format!("device/{mac}/update")
    }
    pub fn data(mac: &str) -> String {
        format!("device/{mac}/data")
    }
    pub const ALL: &str = "home/all";
}

/// Tracks every topic ever seen, purely so the "MQTT Monitor" UI screen has
/// something to list. Routing doesn't consult this — it matches each publish
/// directly against each connected client's live subscription filters.
#[derive(Default)]
pub struct TopicManager {
    known: RwLock<HashSet<String>>,
}

impl TopicManager {
    pub fn observe(&self, topic: &str) {
        let mut set = self.known.write();
        if !set.contains(topic) {
            set.insert(topic.to_string());
        }
    }

    pub fn snapshot(&self) -> Vec<String> {
        let mut v: Vec<String> = self.known.read().iter().cloned().collect();
        v.sort();
        v
    }
}
