use chrono::{DateTime, Utc};
use luma_core::error::{LumaError, LumaResult};
use mqttbytes::v4::{LastWill, Packet};
use parking_lot::RwLock;
use std::collections::HashMap;
use std::sync::Arc;
use tokio::sync::{mpsc, Notify};

pub const MAX_CLIENTS: usize = 5;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ClientStatus {
    Connected,
    Disconnected,
}

/// Everything the broker knows about one connected (or recently-connected,
/// if it has a persistent session) ESP32.
pub struct ClientHandle {
    pub client_id: String,
    pub mac_address: Option<String>,
    pub ip_address: String,
    pub connected_at: DateTime<Utc>,
    pub last_seen: DateTime<Utc>,
    pub clean_session: bool,
    pub status: ClientStatus,
    /// RSSI as last self-reported by the device over `device/{id}/status` —
    /// the broker itself has no radio-level visibility into WiFi signal
    /// strength, so this is populated opportunistically, not measured.
    pub rssi: Option<i32>,
    pub subscriptions: Vec<String>,
    pub last_will: Option<LastWill>,
    /// Channel into this client's dedicated writer task. `None` once the
    /// client has disconnected but is being kept around for its persistent
    /// session (clean_session = false).
    pub sender: Option<mpsc::Sender<Packet>>,
    /// pkid counter for broker-initiated (QoS>=1) deliveries to this client.
    pub next_pkid: u16,
    /// Signaled when a *new* connection takes over this client_id, so the old
    /// connection's read loop can break out and close its socket cleanly
    /// instead of lingering as a zombie holding a slot.
    pub close_notify: Arc<Notify>,
}

impl ClientHandle {
    pub fn alloc_pkid(&mut self) -> u16 {
        self.next_pkid = self.next_pkid.wrapping_add(1);
        if self.next_pkid == 0 {
            self.next_pkid = 1;
        }
        self.next_pkid
    }
}

#[derive(Clone, Debug)]
pub struct ClientSnapshot {
    pub client_id: String,
    pub mac_address: Option<String>,
    pub ip_address: String,
    pub connected: bool,
    pub clean_session: bool,
    pub subscriptions: Vec<String>,
    pub connected_at: DateTime<Utc>,
    pub last_seen: DateTime<Utc>,
    pub rssi: Option<i32>,
}

/// Owns every `ClientHandle`. Enforces the "max 5 simultaneously connected
/// ESP32 devices" requirement — counts only *live* sockets, not clients that
/// are merely retaining a persistent session while offline, since those
/// don't hold a connection slot.
#[derive(Default)]
pub struct ClientManager {
    clients: RwLock<HashMap<String, ClientHandle>>,
}

impl ClientManager {
    pub fn connected_count(&self) -> usize {
        self.clients.read().values().filter(|c| c.status == ClientStatus::Connected).count()
    }

    pub fn has_capacity_for(&self, client_id: &str) -> bool {
        let clients = self.clients.read();
        if clients.get(client_id).map(|c| c.status == ClientStatus::Connected).unwrap_or(false) {
            // Reconnecting with the same id takes over its own slot, not a new one.
            return true;
        }
        clients.values().filter(|c| c.status == ClientStatus::Connected).count() < MAX_CLIENTS
    }

    /// Registers a newly-connected client, taking over any existing slot with
    /// the same client_id (standard MQTT behavior: last connection wins).
    /// Returns the replaced handle, if any, so the caller can wake its reader
    /// loop via `close_notify` before dropping it.
    pub fn connect(&self, handle: ClientHandle) -> Option<ClientHandle> {
        let mut clients = self.clients.write();
        let previous = clients.insert(handle.client_id.clone(), handle);
        if let Some(p) = &previous {
            p.close_notify.notify_one();
        }
        previous
    }

    pub fn mark_disconnected(&self, client_id: &str) {
        let mut clients = self.clients.write();
        if let Some(c) = clients.get_mut(client_id) {
            c.status = ClientStatus::Disconnected;
            c.sender = None;
            c.last_seen = Utc::now();
        }
    }

    pub fn remove(&self, client_id: &str) {
        self.clients.write().remove(client_id);
    }

    pub fn touch(&self, client_id: &str) {
        if let Some(c) = self.clients.write().get_mut(client_id) {
            c.last_seen = Utc::now();
        }
    }

    pub fn set_subscriptions(&self, client_id: &str, filters: Vec<String>) {
        if let Some(c) = self.clients.write().get_mut(client_id) {
            for f in filters {
                if !c.subscriptions.contains(&f) {
                    c.subscriptions.push(f);
                }
            }
        }
    }

    pub fn remove_subscriptions(&self, client_id: &str, filters: &[String]) {
        if let Some(c) = self.clients.write().get_mut(client_id) {
            c.subscriptions.retain(|f| !filters.contains(f));
        }
    }

    pub fn alloc_pkid(&self, client_id: &str) -> Option<u16> {
        self.clients.write().get_mut(client_id).map(|c| c.alloc_pkid())
    }

    /// Every currently-*connected* client whose subscriptions include a filter
    /// matching `topic`, paired with a clone of their outbound sender.
    pub fn matching_senders(&self, topic: &str) -> Vec<(String, mpsc::Sender<Packet>)> {
        self.clients
            .read()
            .values()
            .filter(|c| c.status == ClientStatus::Connected)
            .filter(|c| c.subscriptions.iter().any(|f| mqttbytes::matches(topic, f)))
            .filter_map(|c| c.sender.clone().map(|s| (c.client_id.clone(), s)))
            .collect()
    }

    pub fn is_connected(&self, client_id: &str) -> bool {
        self.clients.read().get(client_id).map(|c| c.status == ClientStatus::Connected).unwrap_or(false)
    }

    pub fn get_sender(&self, client_id: &str) -> Option<mpsc::Sender<Packet>> {
        self.clients.read().get(client_id).and_then(|c| c.sender.clone())
    }

    pub fn last_will(&self, client_id: &str) -> Option<LastWill> {
        self.clients.read().get(client_id).and_then(|c| c.last_will.clone())
    }

    pub fn update_rssi(&self, client_id: &str, rssi: i32) {
        if let Some(c) = self.clients.write().get_mut(client_id) {
            c.rssi = Some(rssi);
        }
    }

    pub fn snapshot(&self) -> Vec<ClientSnapshot> {
        self.clients
            .read()
            .values()
            .map(|c| ClientSnapshot {
                client_id: c.client_id.clone(),
                mac_address: c.mac_address.clone(),
                ip_address: c.ip_address.clone(),
                connected: c.status == ClientStatus::Connected,
                clean_session: c.clean_session,
                subscriptions: c.subscriptions.clone(),
                connected_at: c.connected_at,
                last_seen: c.last_seen,
                rssi: c.rssi,
            })
            .collect()
    }

    pub fn require_capacity(&self, client_id: &str) -> LumaResult<()> {
        if self.has_capacity_for(client_id) {
            Ok(())
        } else {
            Err(LumaError::Mqtt(format!(
                "broker is at capacity ({MAX_CLIENTS} devices); rejecting connect from {client_id}"
            )))
        }
    }
}
