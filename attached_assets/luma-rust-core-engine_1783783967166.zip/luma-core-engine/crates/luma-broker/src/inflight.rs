use mqttbytes::v4::Publish;
use parking_lot::Mutex;
use std::collections::HashMap;
use std::time::{Duration, Instant};

const MAX_RETRIES: u32 = 3;
const RETRY_INTERVAL: Duration = Duration::from_secs(5);

struct InFlight {
    client_id: String,
    publish: Publish,
    sent_at: Instant,
    attempts: u32,
}

/// Tracks every QoS1 publish the broker has sent to a subscriber that hasn't
/// been PUBACK'd yet. A periodic sweep (driven from `BrokerEngine`) resends
/// anything older than `RETRY_INTERVAL`, up to `MAX_RETRIES`, then gives up
/// and logs it — this is the "Retry on failure" / "Delivery acknowledgment"
/// requirement from the design doc.
#[derive(Default)]
pub struct InFlightTracker {
    entries: Mutex<HashMap<(String, u16), InFlight>>,
}

impl InFlightTracker {
    pub fn track(&self, client_id: &str, publish: Publish) {
        self.entries.lock().insert(
            (client_id.to_string(), publish.pkid),
            InFlight { client_id: client_id.to_string(), publish, sent_at: Instant::now(), attempts: 1 },
        );
    }

    pub fn ack(&self, client_id: &str, pkid: u16) {
        self.entries.lock().remove(&(client_id.to_string(), pkid));
    }

    pub fn drop_client(&self, client_id: &str) {
        self.entries.lock().retain(|(cid, _), _| cid != client_id);
    }

    /// Returns (client_id, republish-ready Publish) for everything due a retry,
    /// and drops entries that have exhausted their retry budget.
    pub fn due_for_retry(&self) -> Vec<(String, Publish)> {
        let mut out = Vec::new();
        let mut entries = self.entries.lock();
        entries.retain(|_, entry| {
            if entry.sent_at.elapsed() < RETRY_INTERVAL {
                return true;
            }
            if entry.attempts >= MAX_RETRIES {
                tracing::warn!(
                    client_id = %entry.client_id,
                    pkid = entry.publish.pkid,
                    "giving up on QoS1 delivery after max retries"
                );
                return false;
            }
            let mut retry_publish = entry.publish.clone();
            retry_publish.dup = true;
            out.push((entry.client_id.clone(), retry_publish));
            entry.attempts += 1;
            entry.sent_at = Instant::now();
            true
        });
        out
    }
}
