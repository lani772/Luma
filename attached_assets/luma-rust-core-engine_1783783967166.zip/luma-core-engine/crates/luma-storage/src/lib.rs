mod schema;

use chrono::Utc;
use luma_core::error::{LumaError, LumaResult};
use luma_core::models::{Automation, Device, DeviceStatus, LogEntry, Notification, Scene};
use r2d2::Pool;
use r2d2_sqlite::SqliteConnectionManager;
use rusqlite::params;
use std::sync::Arc;

pub type DbPool = Pool<SqliteConnectionManager>;

/// The Local Database Engine (design goal 12). Backed by SQLite with WAL mode
/// so reads and writes don't block each other — important since the
/// automation engine reads devices constantly while MQTT writes state updates.
#[derive(Clone)]
pub struct Storage {
    pool: Arc<DbPool>,
}

fn map_err(e: rusqlite::Error) -> LumaError {
    LumaError::Storage(e.to_string())
}

impl Storage {
    pub fn open(path: &str) -> LumaResult<Self> {
        let manager = SqliteConnectionManager::file(path);
        let pool = Pool::new(manager).map_err(|e| LumaError::Storage(e.to_string()))?;
        let conn = pool.get().map_err(|e| LumaError::Storage(e.to_string()))?;
        conn.execute_batch(schema::SCHEMA).map_err(map_err)?;
        Ok(Self { pool: Arc::new(pool) })
    }

    pub fn in_memory() -> LumaResult<Self> {
        let manager = SqliteConnectionManager::memory();
        let pool = Pool::new(manager).map_err(|e| LumaError::Storage(e.to_string()))?;
        let conn = pool.get().map_err(|e| LumaError::Storage(e.to_string()))?;
        conn.execute_batch(schema::SCHEMA).map_err(map_err)?;
        Ok(Self { pool: Arc::new(pool) })
    }

    // ---------------- Devices ----------------

    pub fn upsert_device(&self, d: &Device) -> LumaResult<()> {
        let conn = self.pool.get().map_err(|e| LumaError::Storage(e.to_string()))?;
        conn.execute(
            "INSERT INTO devices (id, name, room_id, device_type, capabilities, firmware_version,
                mac_address, ip_address, status, last_seen, reported_state, desired_state, created_at, updated_at)
             VALUES (?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,?12,?13,?14)
             ON CONFLICT(id) DO UPDATE SET
                name=excluded.name, room_id=excluded.room_id, device_type=excluded.device_type,
                capabilities=excluded.capabilities, firmware_version=excluded.firmware_version,
                ip_address=excluded.ip_address, status=excluded.status, last_seen=excluded.last_seen,
                reported_state=excluded.reported_state, desired_state=excluded.desired_state,
                updated_at=excluded.updated_at",
            params![
                d.id,
                d.name,
                d.room_id,
                d.device_type,
                serde_json::to_string(&d.capabilities).map_err(LumaError::Serde)?,
                d.firmware_version,
                d.mac_address,
                d.ip_address,
                format!("{:?}", d.status),
                d.last_seen.map(|t| t.to_rfc3339()),
                d.reported_state.to_string(),
                d.desired_state.to_string(),
                d.created_at.to_rfc3339(),
                d.updated_at.to_rfc3339(),
            ],
        ).map_err(map_err)?;
        Ok(())
    }

    pub fn get_device(&self, id: &str) -> LumaResult<Device> {
        let conn = self.pool.get().map_err(|e| LumaError::Storage(e.to_string()))?;
        conn.query_row("SELECT * FROM devices WHERE id = ?1", params![id], row_to_device)
            .map_err(|e| match e {
                rusqlite::Error::QueryReturnedNoRows => LumaError::DeviceNotFound(id.to_string()),
                other => map_err(other),
            })
    }

    pub fn list_devices(&self) -> LumaResult<Vec<Device>> {
        let conn = self.pool.get().map_err(|e| LumaError::Storage(e.to_string()))?;
        let mut stmt = conn.prepare("SELECT * FROM devices ORDER BY name").map_err(map_err)?;
        let rows = stmt.query_map([], row_to_device).map_err(map_err)?;
        rows.collect::<Result<Vec<_>, _>>().map_err(map_err)
    }

    pub fn delete_device(&self, id: &str) -> LumaResult<()> {
        let conn = self.pool.get().map_err(|e| LumaError::Storage(e.to_string()))?;
        conn.execute("DELETE FROM devices WHERE id = ?1", params![id]).map_err(map_err)?;
        Ok(())
    }

    pub fn set_device_status(&self, id: &str, status: DeviceStatus) -> LumaResult<()> {
        let conn = self.pool.get().map_err(|e| LumaError::Storage(e.to_string()))?;
        conn.execute(
            "UPDATE devices SET status = ?1, last_seen = ?2, updated_at = ?3 WHERE id = ?4",
            params![format!("{:?}", status), Utc::now().to_rfc3339(), Utc::now().to_rfc3339(), id],
        ).map_err(map_err)?;
        Ok(())
    }

    pub fn merge_reported_state(&self, id: &str, patch: &serde_json::Value) -> LumaResult<Device> {
        let mut device = self.get_device(id)?;
        merge_json(&mut device.reported_state, patch);
        device.updated_at = Utc::now();
        self.upsert_device(&device)?;
        Ok(device)
    }

    // ---------------- Automations ----------------

    pub fn upsert_automation(&self, a: &Automation) -> LumaResult<()> {
        let conn = self.pool.get().map_err(|e| LumaError::Storage(e.to_string()))?;
        conn.execute(
            "INSERT INTO automations (id, name, enabled, trigger_json, conditions_json, actions_json, created_at)
             VALUES (?1,?2,?3,?4,?5,?6,?7)
             ON CONFLICT(id) DO UPDATE SET name=excluded.name, enabled=excluded.enabled,
                trigger_json=excluded.trigger_json, conditions_json=excluded.conditions_json,
                actions_json=excluded.actions_json",
            params![
                a.id,
                a.name,
                a.enabled as i32,
                serde_json::to_string(&a.trigger).map_err(LumaError::Serde)?,
                serde_json::to_string(&a.conditions).map_err(LumaError::Serde)?,
                serde_json::to_string(&a.actions).map_err(LumaError::Serde)?,
                a.created_at.to_rfc3339(),
            ],
        ).map_err(map_err)?;
        Ok(())
    }

    pub fn list_automations(&self) -> LumaResult<Vec<Automation>> {
        let conn = self.pool.get().map_err(|e| LumaError::Storage(e.to_string()))?;
        let mut stmt = conn.prepare("SELECT * FROM automations").map_err(map_err)?;
        let rows = stmt.query_map([], row_to_automation).map_err(map_err)?;
        rows.collect::<Result<Vec<_>, _>>().map_err(map_err)
    }

    pub fn delete_automation(&self, id: &str) -> LumaResult<()> {
        let conn = self.pool.get().map_err(|e| LumaError::Storage(e.to_string()))?;
        conn.execute("DELETE FROM automations WHERE id = ?1", params![id]).map_err(map_err)?;
        Ok(())
    }

    // ---------------- Scenes ----------------

    pub fn upsert_scene(&self, s: &Scene) -> LumaResult<()> {
        let conn = self.pool.get().map_err(|e| LumaError::Storage(e.to_string()))?;
        conn.execute(
            "INSERT INTO scenes (id, name, actions_json) VALUES (?1,?2,?3)
             ON CONFLICT(id) DO UPDATE SET name=excluded.name, actions_json=excluded.actions_json",
            params![s.id, s.name, serde_json::to_string(&s.actions).map_err(LumaError::Serde)?],
        ).map_err(map_err)?;
        Ok(())
    }

    pub fn get_scene(&self, id: &str) -> LumaResult<Scene> {
        let conn = self.pool.get().map_err(|e| LumaError::Storage(e.to_string()))?;
        conn.query_row("SELECT * FROM scenes WHERE id = ?1", params![id], row_to_scene)
            .map_err(map_err)
    }

    pub fn list_scenes(&self) -> LumaResult<Vec<Scene>> {
        let conn = self.pool.get().map_err(|e| LumaError::Storage(e.to_string()))?;
        let mut stmt = conn.prepare("SELECT * FROM scenes").map_err(map_err)?;
        let rows = stmt.query_map([], row_to_scene).map_err(map_err)?;
        rows.collect::<Result<Vec<_>, _>>().map_err(map_err)
    }

    // ---------------- Logs & Notifications ----------------

    pub fn add_log(&self, entry: &LogEntry) -> LumaResult<()> {
        let conn = self.pool.get().map_err(|e| LumaError::Storage(e.to_string()))?;
        conn.execute(
            "INSERT INTO logs (id, level, source, message, timestamp) VALUES (?1,?2,?3,?4,?5)",
            params![entry.id, entry.level, entry.source, entry.message, entry.timestamp.to_rfc3339()],
        ).map_err(map_err)?;
        Ok(())
    }

    pub fn recent_logs(&self, limit: u32) -> LumaResult<Vec<LogEntry>> {
        let conn = self.pool.get().map_err(|e| LumaError::Storage(e.to_string()))?;
        let mut stmt = conn
            .prepare("SELECT id, level, source, message, timestamp FROM logs ORDER BY timestamp DESC LIMIT ?1")
            .map_err(map_err)?;
        let rows = stmt
            .query_map(params![limit], |row| {
                Ok(LogEntry {
                    id: row.get(0)?,
                    level: row.get(1)?,
                    source: row.get(2)?,
                    message: row.get(3)?,
                    timestamp: row.get::<_, String>(4)?.parse().unwrap_or_else(|_| Utc::now()),
                })
            })
            .map_err(map_err)?;
        rows.collect::<Result<Vec<_>, _>>().map_err(map_err)
    }

    pub fn add_notification(&self, n: &Notification) -> LumaResult<()> {
        let conn = self.pool.get().map_err(|e| LumaError::Storage(e.to_string()))?;
        conn.execute(
            "INSERT INTO notifications (id, title, body, read, created_at) VALUES (?1,?2,?3,?4,?5)",
            params![n.id, n.title, n.body, n.read as i32, n.created_at.to_rfc3339()],
        ).map_err(map_err)?;
        Ok(())
    }

    // ---------------- Offline outbox (design goal 2 & 6) ----------------

    pub fn enqueue_outbox(&self, topic: &str, payload: &str, qos: i32) -> LumaResult<()> {
        let conn = self.pool.get().map_err(|e| LumaError::Storage(e.to_string()))?;
        conn.execute(
            "INSERT INTO outbox (id, topic, payload, qos, retries, created_at) VALUES (?1,?2,?3,?4,0,?5)",
            params![uuid::Uuid::new_v4().to_string(), topic, payload, qos, Utc::now().to_rfc3339()],
        ).map_err(map_err)?;
        Ok(())
    }

    pub fn drain_outbox(&self, max: u32) -> LumaResult<Vec<(String, String, String, i32)>> {
        let conn = self.pool.get().map_err(|e| LumaError::Storage(e.to_string()))?;
        let mut stmt = conn
            .prepare("SELECT id, topic, payload, qos FROM outbox ORDER BY created_at LIMIT ?1")
            .map_err(map_err)?;
        let rows = stmt
            .query_map(params![max], |row| {
                Ok((row.get(0)?, row.get(1)?, row.get(2)?, row.get(3)?))
            })
            .map_err(map_err)?;
        rows.collect::<Result<Vec<_>, _>>().map_err(map_err)
    }

    pub fn remove_outbox(&self, id: &str) -> LumaResult<()> {
        let conn = self.pool.get().map_err(|e| LumaError::Storage(e.to_string()))?;
        conn.execute("DELETE FROM outbox WHERE id = ?1", params![id]).map_err(map_err)?;
        Ok(())
    }

    // ---------------- Telemetry cache ----------------

    pub fn record_telemetry(&self, device_id: &str, path: &str, value: &serde_json::Value) -> LumaResult<()> {
        let conn = self.pool.get().map_err(|e| LumaError::Storage(e.to_string()))?;
        conn.execute(
            "INSERT INTO telemetry (device_id, path, value, recorded_at) VALUES (?1,?2,?3,?4)",
            params![device_id, path, value.to_string(), Utc::now().to_rfc3339()],
        ).map_err(map_err)?;
        Ok(())
    }

    // ---------------- Broker: persistent session message queue ----------------

    pub fn enqueue_session_message(&self, client_id: &str, topic: &str, payload: &[u8], qos: i32) -> LumaResult<()> {
        let conn = self.pool.get().map_err(|e| LumaError::Storage(e.to_string()))?;
        conn.execute(
            "INSERT INTO session_queue (id, client_id, topic, payload, qos, created_at) VALUES (?1,?2,?3,?4,?5,?6)",
            params![uuid::Uuid::new_v4().to_string(), client_id, topic, payload, qos, Utc::now().to_rfc3339()],
        ).map_err(map_err)?;
        Ok(())
    }

    /// Returns (id, topic, payload, qos) ordered oldest-first, ready to replay
    /// the instant the client reconnects.
    pub fn drain_session_messages(&self, client_id: &str, max: u32) -> LumaResult<Vec<(String, String, Vec<u8>, i32)>> {
        let conn = self.pool.get().map_err(|e| LumaError::Storage(e.to_string()))?;
        let mut stmt = conn
            .prepare("SELECT id, topic, payload, qos FROM session_queue WHERE client_id = ?1 ORDER BY created_at LIMIT ?2")
            .map_err(map_err)?;
        let rows = stmt
            .query_map(params![client_id, max], |row| {
                Ok((row.get(0)?, row.get(1)?, row.get(2)?, row.get(3)?))
            })
            .map_err(map_err)?;
        rows.collect::<Result<Vec<_>, _>>().map_err(map_err)
    }

    pub fn remove_session_message(&self, id: &str) -> LumaResult<()> {
        let conn = self.pool.get().map_err(|e| LumaError::Storage(e.to_string()))?;
        conn.execute("DELETE FROM session_queue WHERE id = ?1", params![id]).map_err(map_err)?;
        Ok(())
    }

    pub fn clear_session_messages(&self, client_id: &str) -> LumaResult<()> {
        let conn = self.pool.get().map_err(|e| LumaError::Storage(e.to_string()))?;
        conn.execute("DELETE FROM session_queue WHERE client_id = ?1", params![client_id]).map_err(map_err)?;
        Ok(())
    }

    pub fn count_session_messages(&self, client_id: &str) -> LumaResult<u32> {
        let conn = self.pool.get().map_err(|e| LumaError::Storage(e.to_string()))?;
        conn.query_row(
            "SELECT COUNT(*) FROM session_queue WHERE client_id = ?1",
            params![client_id],
            |row| row.get::<_, i64>(0),
        ).map(|c| c as u32).map_err(map_err)
    }

    // ---------------- Broker: known client identities ----------------

    pub fn upsert_broker_client(
        &self,
        client_id: &str,
        mac_address: Option<&str>,
        friendly_name: Option<&str>,
        clean_session: bool,
        subscriptions: &[String],
        last_will_json: Option<&str>,
    ) -> LumaResult<()> {
        let conn = self.pool.get().map_err(|e| LumaError::Storage(e.to_string()))?;
        let now = Utc::now().to_rfc3339();
        conn.execute(
            "INSERT INTO broker_clients (client_id, mac_address, friendly_name, clean_session, subscriptions_json, last_will_json, first_connected_at, last_connected_at)
             VALUES (?1,?2,?3,?4,?5,?6,?7,?7)
             ON CONFLICT(client_id) DO UPDATE SET
                mac_address=excluded.mac_address, friendly_name=COALESCE(excluded.friendly_name, broker_clients.friendly_name),
                clean_session=excluded.clean_session, subscriptions_json=excluded.subscriptions_json,
                last_will_json=excluded.last_will_json, last_connected_at=excluded.last_connected_at",
            params![
                client_id,
                mac_address,
                friendly_name,
                clean_session as i32,
                serde_json::to_string(subscriptions).unwrap_or_else(|_| "[]".into()),
                last_will_json,
                now,
            ],
        ).map_err(map_err)?;
        Ok(())
    }

    pub fn get_broker_client_subscriptions(&self, client_id: &str) -> LumaResult<Vec<String>> {
        let conn = self.pool.get().map_err(|e| LumaError::Storage(e.to_string()))?;
        let json: Option<String> = conn
            .query_row(
                "SELECT subscriptions_json FROM broker_clients WHERE client_id = ?1",
                params![client_id],
                |row| row.get(0),
            )
            .ok();
        Ok(json.and_then(|s| serde_json::from_str(&s).ok()).unwrap_or_default())
    }

    /// All clients that asked for a persistent session (clean_session = 0),
    /// so the broker can pre-populate its in-memory client table on boot —
    /// otherwise a command sent before the device's first post-restart
    /// reconnect would have nowhere to be queued.
    pub fn list_persistent_broker_clients(&self) -> LumaResult<Vec<(String, Option<String>, Vec<String>)>> {
        let conn = self.pool.get().map_err(|e| LumaError::Storage(e.to_string()))?;
        let mut stmt = conn
            .prepare("SELECT client_id, mac_address, subscriptions_json FROM broker_clients WHERE clean_session = 0")
            .map_err(map_err)?;
        let rows = stmt
            .query_map([], |row| {
                let client_id: String = row.get(0)?;
                let mac: Option<String> = row.get(1)?;
                let subs_json: String = row.get(2)?;
                Ok((client_id, mac, subs_json))
            })
            .map_err(map_err)?;
        let mut out = Vec::new();
        for r in rows {
            let (client_id, mac, subs_json) = r.map_err(map_err)?;
            let subs: Vec<String> = serde_json::from_str(&subs_json).unwrap_or_default();
            out.push((client_id, mac, subs));
        }
        Ok(out)
    }
}

fn merge_json(base: &mut serde_json::Value, patch: &serde_json::Value) {
    if let (Some(base_obj), Some(patch_obj)) = (base.as_object_mut(), patch.as_object()) {
        for (k, v) in patch_obj {
            merge_json(base_obj.entry(k.clone()).or_insert(serde_json::Value::Null), v);
        }
    } else {
        *base = patch.clone();
    }
}

fn row_to_device(row: &rusqlite::Row) -> rusqlite::Result<Device> {
    let status_str: String = row.get("status")?;
    let status = match status_str.as_str() {
        "Online" => DeviceStatus::Online,
        "Offline" => DeviceStatus::Offline,
        "Updating" => DeviceStatus::Updating,
        "Error" => DeviceStatus::Error,
        _ => DeviceStatus::Provisioning,
    };
    let capabilities_str: String = row.get("capabilities")?;
    let reported_state_str: String = row.get("reported_state")?;
    let desired_state_str: String = row.get("desired_state")?;
    let last_seen_str: Option<String> = row.get("last_seen")?;
    let created_at_str: String = row.get("created_at")?;
    let updated_at_str: String = row.get("updated_at")?;

    Ok(Device {
        id: row.get("id")?,
        name: row.get("name")?,
        room_id: row.get("room_id")?,
        device_type: row.get("device_type")?,
        capabilities: serde_json::from_str(&capabilities_str).unwrap_or_default(),
        firmware_version: row.get("firmware_version")?,
        mac_address: row.get("mac_address")?,
        ip_address: row.get("ip_address")?,
        status,
        last_seen: last_seen_str.and_then(|s| s.parse().ok()),
        reported_state: serde_json::from_str(&reported_state_str).unwrap_or(serde_json::json!({})),
        desired_state: serde_json::from_str(&desired_state_str).unwrap_or(serde_json::json!({})),
        created_at: created_at_str.parse().unwrap_or_else(|_| Utc::now()),
        updated_at: updated_at_str.parse().unwrap_or_else(|_| Utc::now()),
    })
}

fn row_to_automation(row: &rusqlite::Row) -> rusqlite::Result<Automation> {
    let trigger_str: String = row.get("trigger_json")?;
    let conditions_str: String = row.get("conditions_json")?;
    let actions_str: String = row.get("actions_json")?;
    let created_at_str: String = row.get("created_at")?;
    Ok(Automation {
        id: row.get("id")?,
        name: row.get("name")?,
        enabled: row.get::<_, i32>("enabled")? != 0,
        trigger: serde_json::from_str(&trigger_str).unwrap(),
        conditions: serde_json::from_str(&conditions_str).unwrap_or_default(),
        actions: serde_json::from_str(&actions_str).unwrap_or_default(),
        created_at: created_at_str.parse().unwrap_or_else(|_| Utc::now()),
    })
}

fn row_to_scene(row: &rusqlite::Row) -> rusqlite::Result<Scene> {
    let actions_str: String = row.get("actions_json")?;
    Ok(Scene {
        id: row.get("id")?,
        name: row.get("name")?,
        actions: serde_json::from_str(&actions_str).unwrap_or_default(),
    })
}
