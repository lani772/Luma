pub const SCHEMA: &str = r#"
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS homes (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    timezone TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS rooms (
    id TEXT PRIMARY KEY,
    home_id TEXT NOT NULL REFERENCES homes(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    icon TEXT
);

CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    email TEXT NOT NULL UNIQUE,
    display_name TEXT NOT NULL,
    role TEXT NOT NULL,
    password_hash TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS devices (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    room_id TEXT REFERENCES rooms(id) ON DELETE SET NULL,
    device_type TEXT NOT NULL,
    capabilities TEXT NOT NULL DEFAULT '[]',
    firmware_version TEXT NOT NULL DEFAULT 'unknown',
    mac_address TEXT NOT NULL UNIQUE,
    ip_address TEXT,
    status TEXT NOT NULL DEFAULT 'Provisioning',
    last_seen TEXT,
    reported_state TEXT NOT NULL DEFAULT '{}',
    desired_state TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_devices_room ON devices(room_id);
CREATE INDEX IF NOT EXISTS idx_devices_status ON devices(status);

CREATE TABLE IF NOT EXISTS automations (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    enabled INTEGER NOT NULL DEFAULT 1,
    trigger_json TEXT NOT NULL,
    conditions_json TEXT NOT NULL DEFAULT '[]',
    actions_json TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS scenes (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    actions_json TEXT NOT NULL DEFAULT '[]'
);

CREATE TABLE IF NOT EXISTS logs (
    id TEXT PRIMARY KEY,
    level TEXT NOT NULL,
    source TEXT NOT NULL,
    message TEXT NOT NULL,
    timestamp TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_logs_timestamp ON logs(timestamp);

CREATE TABLE IF NOT EXISTS notifications (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    body TEXT NOT NULL,
    read INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
);

-- Offline outbound message queue: anything the MQTT engine couldn't send
-- immediately (design goal 2 "Offline First" / 6 "Reliable Communication").
CREATE TABLE IF NOT EXISTS outbox (
    id TEXT PRIMARY KEY,
    topic TEXT NOT NULL,
    payload TEXT NOT NULL,
    qos INTEGER NOT NULL DEFAULT 1,
    retries INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
);

-- Cached telemetry samples for offline charts / history.
CREATE TABLE IF NOT EXISTS telemetry (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    device_id TEXT NOT NULL,
    path TEXT NOT NULL,
    value TEXT NOT NULL,
    recorded_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_telemetry_device ON telemetry(device_id, recorded_at);

-- Persistent-session message queue for the embedded MQTT BROKER (luma-broker).
-- When a client connects with clean_session=false and later goes offline,
-- QoS>=1 publishes destined for it accumulate here instead of being dropped,
-- and get flushed back out the moment it reconnects.
CREATE TABLE IF NOT EXISTS session_queue (
    id TEXT PRIMARY KEY,
    client_id TEXT NOT NULL,
    topic TEXT NOT NULL,
    payload BLOB NOT NULL,
    qos INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_session_queue_client ON session_queue(client_id, created_at);

-- Known broker client identities, persisted across app restarts so a
-- reconnecting ESP32 is recognized (friendly name, whether it wants a
-- persistent session) even before it re-announces itself.
CREATE TABLE IF NOT EXISTS broker_clients (
    client_id TEXT PRIMARY KEY,
    mac_address TEXT,
    friendly_name TEXT,
    clean_session INTEGER NOT NULL DEFAULT 1,
    subscriptions_json TEXT NOT NULL DEFAULT '[]',
    last_will_json TEXT,
    first_connected_at TEXT NOT NULL,
    last_connected_at TEXT NOT NULL
);
"#;
