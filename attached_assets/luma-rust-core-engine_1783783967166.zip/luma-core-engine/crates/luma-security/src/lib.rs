use argon2::password_hash::{PasswordHash, PasswordHasher, PasswordVerifier, SaltString};
use argon2::Argon2;
use base64::Engine as _;
use hmac::{Hmac, Mac};
use luma_core::error::{LumaError, LumaResult};
use rand_core::OsRng;
use sha2::Sha256;

type HmacSha256 = Hmac<Sha256>;

/// User password hashing (Argon2id) — used by luma-ffi when creating/authenticating users.
pub fn hash_password(plain: &str) -> LumaResult<String> {
    let salt = SaltString::generate(&mut OsRng);
    let argon2 = Argon2::default();
    argon2
        .hash_password(plain.as_bytes(), &salt)
        .map(|h| h.to_string())
        .map_err(|e| LumaError::Security(e.to_string()))
}

pub fn verify_password(plain: &str, hash: &str) -> LumaResult<bool> {
    let parsed = PasswordHash::new(hash).map_err(|e| LumaError::Security(e.to_string()))?;
    Ok(Argon2::default().verify_password(plain.as_bytes(), &parsed).is_ok())
}

/// Signs a short-lived device auth token: `device_id.expiry.signature`.
/// The ESP32 firmware verifies this same signature using the shared home secret
/// before accepting commands over MQTT/BLE, so a compromised topic name alone
/// isn't enough to control a device (design goal 5, "Topic permissions").
pub fn sign_device_token(home_secret: &[u8], device_id: &str, expiry_unix: i64) -> LumaResult<String> {
    let payload = format!("{device_id}.{expiry_unix}");
    let mut mac = HmacSha256::new_from_slice(home_secret).map_err(|e| LumaError::Security(e.to_string()))?;
    mac.update(payload.as_bytes());
    let sig = base64::engine::general_purpose::URL_SAFE_NO_PAD.encode(mac.finalize().into_bytes());
    Ok(format!("{payload}.{sig}"))
}

pub fn verify_device_token(home_secret: &[u8], token: &str, now_unix: i64) -> bool {
    let parts: Vec<&str> = token.rsplitn(2, '.').collect();
    if parts.len() != 2 {
        return false;
    }
    let (sig_b64, payload) = (parts[0], parts[1]);
    let Ok(expected_sig) = base64::engine::general_purpose::URL_SAFE_NO_PAD.decode(sig_b64) else {
        return false;
    };
    let Ok(mut mac) = HmacSha256::new_from_slice(home_secret) else { return false };
    mac.update(payload.as_bytes());
    if mac.verify_slice(&expected_sig).is_err() {
        return false;
    }
    payload
        .split_once('.')
        .and_then(|(_, exp)| exp.parse::<i64>().ok())
        .map(|exp| exp > now_unix)
        .unwrap_or(false)
}

/// Checks whether a role/user is allowed to publish/subscribe on a given
/// device topic. Owners/Admins can touch anything in their home; Members are
/// limited to devices in rooms they've been granted; Guests are read-only.
pub fn topic_allowed(role: &luma_core::models::UserRole, is_write: bool) -> bool {
    use luma_core::models::UserRole::*;
    match role {
        Owner | Admin => true,
        Member => true,
        Guest => !is_write,
    }
}
