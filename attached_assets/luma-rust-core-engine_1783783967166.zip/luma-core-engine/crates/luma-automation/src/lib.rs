use async_trait::async_trait;
use luma_core::engine::Engine;
use luma_core::error::LumaResult;
use luma_core::event_bus::{EventBus, LumaEvent};
use luma_core::models::{Automation, CompareOp, Condition, Device, TriggerKind};
use luma_storage::Storage;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;

pub struct AutomationEngine {
    storage: Storage,
    running: Arc<AtomicBool>,
}

impl AutomationEngine {
    pub fn new(storage: Storage) -> Self {
        Self { storage, running: Arc::new(AtomicBool::new(false)) }
    }
}

#[async_trait]
impl Engine for AutomationEngine {
    fn name(&self) -> &'static str {
        "automation-engine"
    }

    async fn start(&self, bus: EventBus) -> LumaResult<()> {
        self.running.store(true, Ordering::SeqCst);
        let mut rx = bus.subscribe();
        let storage = self.storage.clone();
        let bus_out = bus.clone();
        let running = self.running.clone();

        tokio::spawn(async move {
            while running.load(Ordering::SeqCst) {
                match rx.recv().await {
                    Ok(LumaEvent::DeviceStateChanged { device }) => {
                        evaluate_automations(&storage, &bus_out, &device);
                    }
                    Ok(_) => {}
                    Err(tokio::sync::broadcast::error::RecvError::Lagged(_)) => continue,
                    Err(_) => break,
                }
            }
        });

        Ok(())
    }

    async fn stop(&self) -> LumaResult<()> {
        self.running.store(false, Ordering::SeqCst);
        Ok(())
    }
}

fn evaluate_automations(storage: &Storage, bus: &EventBus, changed_device: &Device) {
    let automations = match storage.list_automations() {
        Ok(a) => a,
        Err(_) => return,
    };

    for automation in automations.into_iter().filter(|a| a.enabled) {
        let trigger_matches = match &automation.trigger {
            TriggerKind::DeviceState { device_id, path, op, value } => {
                device_id == &changed_device.id
                    && compare(&get_path(&changed_device.reported_state, path), op, value)
            }
            // Schedule/Sunrise/Sunset triggers are evaluated by the Scheduler
            // engine, not here — this engine only reacts to live device events.
            _ => false,
        };

        if !trigger_matches {
            continue;
        }

        let conditions_ok = automation.conditions.iter().all(|c| condition_holds(storage, c));
        if !conditions_ok {
            continue;
        }

        run_actions(bus, &automation);
        bus.publish(LumaEvent::AutomationTriggered { automation_id: automation.id.clone() });
    }
}

fn condition_holds(storage: &Storage, c: &Condition) -> bool {
    match storage.get_device(&c.device_id) {
        Ok(d) => compare(&get_path(&d.reported_state, &c.path), &c.op, &c.value),
        Err(_) => false,
    }
}

fn run_actions(bus: &EventBus, automation: &Automation) {
    for action in &automation.actions {
        bus.publish(LumaEvent::DeviceCommand {
            device_id: action.device_id.clone(),
            desired_state: action.set_state.clone(),
        });
    }
}

fn get_path(value: &serde_json::Value, path: &str) -> serde_json::Value {
    let mut current = value;
    for segment in path.split('.') {
        match current.get(segment) {
            Some(v) => current = v,
            None => return serde_json::Value::Null,
        }
    }
    current.clone()
}

fn compare(actual: &serde_json::Value, op: &CompareOp, expected: &serde_json::Value) -> bool {
    match op {
        CompareOp::Eq => actual == expected,
        CompareOp::Neq => actual != expected,
        CompareOp::Gt | CompareOp::Gte | CompareOp::Lt | CompareOp::Lte => {
            let (Some(a), Some(e)) = (actual.as_f64(), expected.as_f64()) else { return false };
            match op {
                CompareOp::Gt => a > e,
                CompareOp::Gte => a >= e,
                CompareOp::Lt => a < e,
                CompareOp::Lte => a <= e,
                _ => unreachable!(),
            }
        }
    }
}

/// Run a scene: fan out all of its actions as DeviceCommand events immediately.
pub fn run_scene(bus: &EventBus, scene: &luma_core::models::Scene) {
    for action in &scene.actions {
        bus.publish(LumaEvent::DeviceCommand {
            device_id: action.device_id.clone(),
            desired_state: action.set_state.clone(),
        });
    }
    bus.publish(LumaEvent::SceneRun { scene_id: scene.id.clone() });
}
