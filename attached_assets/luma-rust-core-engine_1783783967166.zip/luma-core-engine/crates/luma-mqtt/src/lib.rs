use async_trait::async_trait;
use luma_core::engine::{Engine, EngineConfig};
use luma_core::error::{LumaError, LumaResult};
use luma_core::event_bus::{EventBus, LumaEvent};
use luma_storage::Storage;
use rumqttc::{AsyncClient, Event, MqttOptions, Packet, QoS, Transport};
use std::sync::Arc;
use std::time::Duration;
use tokio::sync::Mutex;

/// Topic convention:
///   luma/{home_id}/devices/{device_id}/state    <- device reports (retained)
///   luma/{home_id}/devices/{device_id}/set      -> app commands device
///   luma/{home_id}/devices/{device_id}/status   <- online/offline (LWT)
///   luma/{home_id}/discovery                    <- new device announces itself
pub struct Topics {
    pub home_id: String,
}

impl Topics {
    pub fn state(&self, device_id: &str) -> String {
        format!("luma/{}/devices/{}/state", self.home_id, device_id)
    }
    pub fn set(&self, device_id: &str) -> String {
        format!("luma/{}/devices/{}/set", self.home_id, device_id)
    }
    pub fn status(&self, device_id: &str) -> String {
        format!("luma/{}/devices/{}/status", self.home_id, device_id)
    }
    pub fn state_wildcard(&self) -> String {
        format!("luma/{}/devices/+/state", self.home_id)
    }
    pub fn status_wildcard(&self) -> String {
        format!("luma/{}/devices/+/status", self.home_id)
    }
    pub fn discovery(&self) -> String {
        format!("luma/{}/discovery", self.home_id)
    }
}

pub struct MqttEngine {
    config: EngineConfig,
    storage: Storage,
    client: Mutex<Option<AsyncClient>>,
    running: Arc<std::sync::atomic::AtomicBool>,
}

impl MqttEngine {
    pub fn new(config: EngineConfig, storage: Storage) -> Self {
        Self {
            config,
            storage,
            client: Mutex::new(None),
            running: Arc::new(std::sync::atomic::AtomicBool::new(false)),
        }
    }

    fn topics(&self) -> Topics {
        Topics { home_id: self.config.home_id.clone() }
    }

    pub async fn publish_command(&self, device_id: &str, desired_state: &serde_json::Value) -> LumaResult<()> {
        let topic = self.topics().set(device_id);
        let payload = desired_state.to_string();
        let guard = self.client.lock().await;
        if let Some(client) = guard.as_ref() {
            client
                .publish(&topic, QoS::AtLeastOnce, false, payload.clone())
                .await
                .map_err(|e| LumaError::Mqtt(e.to_string()))?;
        } else {
            // Offline: queue it. The outbox is drained as soon as we reconnect.
            self.storage.enqueue_outbox(&topic, &payload, 1)?;
        }
        Ok(())
    }

}

#[async_trait]
impl Engine for MqttEngine {
    fn name(&self) -> &'static str {
        "mqtt-engine"
    }

    async fn start(&self, bus: EventBus) -> LumaResult<()> {
        let mut opts = MqttOptions::new(
            self.config.mqtt_client_id.clone(),
            self.config.mqtt_host.clone(),
            self.config.mqtt_port,
        );
        opts.set_keep_alive(Duration::from_secs(15));
        if let (Some(u), Some(p)) = (&self.config.mqtt_username, &self.config.mqtt_password) {
            opts.set_credentials(u.clone(), p.clone());
        }
        if self.config.mqtt_use_tls {
            opts.set_transport(Transport::tls_with_default_config());
        }

        let (client, mut eventloop) = AsyncClient::new(opts, 100);
        let topics = self.topics();
        client
            .subscribe(topics.state_wildcard(), QoS::AtLeastOnce)
            .await
            .map_err(|e| LumaError::Mqtt(e.to_string()))?;
        client
            .subscribe(topics.status_wildcard(), QoS::AtLeastOnce)
            .await
            .map_err(|e| LumaError::Mqtt(e.to_string()))?;
        client
            .subscribe(topics.discovery(), QoS::AtLeastOnce)
            .await
            .map_err(|e| LumaError::Mqtt(e.to_string()))?;

        *self.client.lock().await = Some(client.clone());
        self.running.store(true, std::sync::atomic::Ordering::SeqCst);

        let storage = self.storage.clone();
        let running = self.running.clone();
        let bus_task = bus.clone();
        let home_id = self.config.home_id.clone();

        tokio::spawn(async move {
            let mut attempt: u32 = 0;
            while running.load(std::sync::atomic::Ordering::SeqCst) {
                match eventloop.poll().await {
                    Ok(Event::Incoming(Packet::ConnAck(_))) => {
                        attempt = 0;
                        tracing::info!("mqtt connected");
                        bus_task.publish(LumaEvent::MqttConnected);
                    }
                    Ok(Event::Incoming(Packet::Publish(p))) => {
                        handle_publish(&home_id, &p.topic, &p.payload, &storage, &bus_task);
                    }
                    Ok(Event::Incoming(Packet::Disconnect)) => {
                        bus_task.publish(LumaEvent::MqttDisconnected { reason: "broker disconnect".into() });
                    }
                    Err(e) => {
                        attempt += 1;
                        bus_task.publish(LumaEvent::MqttReconnecting { attempt });
                        tracing::warn!(error = %e, attempt, "mqtt connection error, retrying");
                        tokio::time::sleep(Duration::from_millis(backoff_ms(attempt))).await;
                    }
                    _ => {}
                }
            }
        });

        // Periodically flush the offline outbox in case messages piled up.
        let client_for_drain = self.client.lock().await.clone();
        if let Some(c) = client_for_drain {
            let storage2 = self.storage.clone();
            tokio::spawn(async move {
                let mut interval = tokio::time::interval(Duration::from_secs(10));
                loop {
                    interval.tick().await;
                    if let Ok(items) = storage2.drain_outbox(50) {
                        for (id, topic, payload, qos) in items {
                            let qos = match qos {
                                0 => QoS::AtMostOnce,
                                2 => QoS::ExactlyOnce,
                                _ => QoS::AtLeastOnce,
                            };
                            if c.publish(&topic, qos, false, payload).await.is_ok() {
                                let _ = storage2.remove_outbox(&id);
                            }
                        }
                    }
                }
            });
        }

        // Listen on the event bus for outbound commands (e.g. from the
        // automation engine or the FFI layer) and turn them into MQTT publishes.
        {
            let mut rx = bus.subscribe();
            let client_for_cmds = self.client.lock().await.clone();
            let topics_for_cmds = self.topics();
            let storage_for_cmds = self.storage.clone();
            let running_for_cmds = self.running.clone();
            tokio::spawn(async move {
                while running_for_cmds.load(std::sync::atomic::Ordering::SeqCst) {
                    match rx.recv().await {
                        Ok(LumaEvent::DeviceCommand { device_id, desired_state }) => {
                            let topic = topics_for_cmds.set(&device_id);
                            let payload = desired_state.to_string();
                            let sent = if let Some(c) = &client_for_cmds {
                                c.publish(&topic, QoS::AtLeastOnce, false, payload.clone()).await.is_ok()
                            } else {
                                false
                            };
                            if !sent {
                                let _ = storage_for_cmds.enqueue_outbox(&topic, &payload, 1);
                            }
                        }
                        Ok(_) => {}
                        Err(tokio::sync::broadcast::error::RecvError::Lagged(_)) => continue,
                        Err(_) => break,
                    }
                }
            });
        }

        Ok(())
    }

    async fn stop(&self) -> LumaResult<()> {
        self.running.store(false, std::sync::atomic::Ordering::SeqCst);
        if let Some(client) = self.client.lock().await.take() {
            let _ = client.disconnect().await;
        }
        Ok(())
    }
}

fn backoff_ms(attempt: u32) -> u64 {
    let capped = attempt.min(6);
    (500u64) * (1u64 << capped).min(64)
}

fn handle_publish(home_id: &str, topic: &str, payload: &[u8], storage: &Storage, bus: &EventBus) {
    let prefix = format!("luma/{}/devices/", home_id);
    if let Some(rest) = topic.strip_prefix(&prefix) {
        let parts: Vec<&str> = rest.splitn(2, '/').collect();
        if parts.len() != 2 {
            return;
        }
        let device_id = parts[0];
        let kind = parts[1];
        let text = String::from_utf8_lossy(payload).to_string();
        let value: serde_json::Value = serde_json::from_str(&text).unwrap_or(serde_json::Value::String(text.clone()));

        match kind {
            "state" => {
                if let Ok(device) = storage.merge_reported_state(device_id, &value) {
                    let _ = storage.set_device_status(device_id, luma_core::models::DeviceStatus::Online);
                    bus.publish(LumaEvent::DeviceStateChanged { device });
                }
                bus.publish(LumaEvent::DeviceMessageReceived {
                    device_id: device_id.to_string(),
                    topic: topic.to_string(),
                    payload: value,
                });
            }
            "status" => {
                let online = text.eq_ignore_ascii_case("online") || text == "1";
                let status = if online {
                    luma_core::models::DeviceStatus::Online
                } else {
                    luma_core::models::DeviceStatus::Offline
                };
                let _ = storage.set_device_status(device_id, status);
                if online {
                    bus.publish(LumaEvent::DeviceOnline { device_id: device_id.to_string() });
                } else {
                    bus.publish(LumaEvent::DeviceOffline { device_id: device_id.to_string() });
                }
            }
            _ => {}
        }
        return;
    }

    if topic == format!("luma/{}/discovery", home_id) {
        if let (Some(mac), Some(name)) = (value_str(&payload_json(payload), "mac"), value_str(&payload_json(payload), "name")) {
            let device_id = mac.replace(':', "").to_lowercase();
            bus.publish(LumaEvent::DeviceDiscovered { device_id, name, mac_address: mac });
        }
    }
}

fn payload_json(payload: &[u8]) -> serde_json::Value {
    serde_json::from_slice(payload).unwrap_or(serde_json::Value::Null)
}

fn value_str(v: &serde_json::Value, key: &str) -> Option<String> {
    v.get(key)?.as_str().map(|s| s.to_string())
}
