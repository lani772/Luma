use crate::models::{Device, Id};
use serde::{Deserialize, Serialize};
use tokio::sync::broadcast;

/// Every cross-module interaction in the engine flows through one of these events.
/// Modules never call each other directly — they publish/subscribe on the bus.
/// This is what keeps MQTT, Automation, Storage, and Notifications decoupled
/// (see design doc section 13, "Event-Driven Architecture").
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum LumaEvent {
    /// Raw message arrived from an ESP32 over MQTT/BLE/WiFi.
    DeviceMessageReceived { device_id: Id, topic: String, payload: serde_json::Value },
    /// A device's reported (shadow) state changed — this is what the automation
    /// engine and the UI both react to.
    DeviceStateChanged { device: Device },
    DeviceOnline { device_id: Id },
    DeviceOffline { device_id: Id },
    DeviceDiscovered { device_id: Id, name: String, mac_address: String },

    /// Outbound: something wants to command a device. The MQTT engine subscribes
    /// to this and turns it into an actual publish.
    DeviceCommand { device_id: Id, desired_state: serde_json::Value },

    AutomationTriggered { automation_id: Id },
    AutomationFailed { automation_id: Id, reason: String },
    SceneRun { scene_id: Id },

    MqttConnected,
    MqttDisconnected { reason: String },
    MqttReconnecting { attempt: u32 },

    /// Emitted by the embedded broker (luma-broker) at the MQTT session level —
    /// distinct from DeviceOnline/DeviceOffline, which are about the *device*
    /// as a persisted entity. A client can connect/disconnect many times
    /// before ever becoming a fully known device.
    BrokerClientConnected { client_id: Id, ip_address: String, clean_session: bool },
    BrokerClientDisconnected { client_id: Id, graceful: bool },
    BrokerStarted { port: u16 },
    BrokerStopped,

    OtaProgress { device_id: Id, percent: u8 },
    OtaCompleted { device_id: Id, version: String },
    OtaFailed { device_id: Id, reason: String },

    NotificationCreated { notification_id: Id, title: String, body: String },

    SyncStarted,
    SyncCompleted { synced_items: u32 },
    SyncFailed { reason: String },

    EngineStarted,
    EngineStopping,
}

/// Thin wrapper around a tokio broadcast channel. Cloning an EventBus is cheap
/// and gives you an independent subscriber handle — this is how every engine
/// (MQTT, Automation, Storage, Notification...) gets wired together at startup.
#[derive(Clone)]
pub struct EventBus {
    sender: broadcast::Sender<LumaEvent>,
}

impl EventBus {
    pub fn new(capacity: usize) -> Self {
        let (sender, _) = broadcast::channel(capacity);
        Self { sender }
    }

    pub fn publish(&self, event: LumaEvent) {
        // A publish with no active subscribers is not an error — modules may
        // not have started listening yet during boot sequencing.
        let _ = self.sender.send(event);
    }

    pub fn subscribe(&self) -> broadcast::Receiver<LumaEvent> {
        self.sender.subscribe()
    }
}

impl Default for EventBus {
    fn default() -> Self {
        Self::new(1024)
    }
}
