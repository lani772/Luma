use thiserror::Error;

#[derive(Debug, Error)]
pub enum LumaError {
    #[error("storage error: {0}")]
    Storage(String),
    #[error("mqtt error: {0}")]
    Mqtt(String),
    #[error("device not found: {0}")]
    DeviceNotFound(String),
    #[error("automation error: {0}")]
    Automation(String),
    #[error("security error: {0}")]
    Security(String),
    #[error("engine not running")]
    NotRunning,
    #[error("engine already running")]
    AlreadyRunning,
    #[error("serialization error: {0}")]
    Serde(#[from] serde_json::Error),
    #[error("invalid config: {0}")]
    Config(String),
    #[error("internal error: {0}")]
    Internal(String),
}

pub type LumaResult<T> = Result<T, LumaError>;
