use crate::error::{LumaError, LumaResult};
use crate::event_bus::EventBus;
use async_trait::async_trait;
use parking_lot::RwLock;
use std::sync::Arc;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum EngineState {
    Stopped,
    Starting,
    Running,
    Stopping,
}

#[derive(Debug, Clone)]
pub struct EngineConfig {
    pub home_id: String,
    pub db_path: String,
    pub mqtt_host: String,
    pub mqtt_port: u16,
    pub mqtt_client_id: String,
    pub mqtt_username: Option<String>,
    pub mqtt_password: Option<String>,
    pub mqtt_use_tls: bool,
}

impl Default for EngineConfig {
    fn default() -> Self {
        Self {
            home_id: "default-home".into(),
            db_path: "luma.db".into(),
            mqtt_host: "127.0.0.1".into(),
            mqtt_port: 1883,
            mqtt_client_id: "luma-mobile-core".into(),
            mqtt_username: None,
            mqtt_password: None,
            mqtt_use_tls: false,
        }
    }
}

/// Every long-running module (MQTT engine, Automation engine, Scheduler, Sync
/// engine...) implements this so the top-level controller can start/stop them
/// uniformly without knowing their internals. This is what "modular" (design
/// goal #3) actually looks like in code.
#[async_trait]
pub trait Engine: Send + Sync {
    fn name(&self) -> &'static str;
    async fn start(&self, bus: EventBus) -> LumaResult<()>;
    async fn stop(&self) -> LumaResult<()>;
}

/// Top-level orchestrator. This is what the FFI layer holds a single instance
/// of and drives via startEngine()/stopEngine().
pub struct EngineController {
    pub config: EngineConfig,
    pub bus: EventBus,
    state: Arc<RwLock<EngineState>>,
    modules: RwLock<Vec<Arc<dyn Engine>>>,
}

impl EngineController {
    pub fn new(config: EngineConfig) -> Self {
        Self {
            config,
            bus: EventBus::default(),
            state: Arc::new(RwLock::new(EngineState::Stopped)),
            modules: RwLock::new(Vec::new()),
        }
    }

    pub fn state(&self) -> EngineState {
        *self.state.read()
    }

    pub fn register(&self, module: Arc<dyn Engine>) {
        self.modules.write().push(module);
    }

    pub async fn start(&self) -> LumaResult<()> {
        {
            let mut s = self.state.write();
            if *s == EngineState::Running || *s == EngineState::Starting {
                return Err(LumaError::AlreadyRunning);
            }
            *s = EngineState::Starting;
        }

        let modules: Vec<Arc<dyn Engine>> = self.modules.read().clone();
        for module in &modules {
            tracing::info!(module = module.name(), "starting engine module");
            module.start(self.bus.clone()).await.map_err(|e| {
                tracing::error!(module = module.name(), error = %e, "module failed to start");
                e
            })?;
        }

        *self.state.write() = EngineState::Running;
        self.bus.publish(crate::event_bus::LumaEvent::EngineStarted);
        Ok(())
    }

    pub async fn stop(&self) -> LumaResult<()> {
        {
            let mut s = self.state.write();
            if *s != EngineState::Running {
                return Err(LumaError::NotRunning);
            }
            *s = EngineState::Stopping;
        }
        self.bus.publish(crate::event_bus::LumaEvent::EngineStopping);

        let modules: Vec<Arc<dyn Engine>> = self.modules.read().clone();
        for module in modules.iter().rev() {
            if let Err(e) = module.stop().await {
                tracing::warn!(module = module.name(), error = %e, "module failed to stop cleanly");
            }
        }

        *self.state.write() = EngineState::Stopped;
        Ok(())
    }
}
