use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use uuid::Uuid;

pub type Id = String;

fn new_id() -> Id {
    Uuid::new_v4().to_string()
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum DeviceCapability {
    Switch,
    Dimmer,
    RgbLight,
    Thermostat,
    MotionSensor,
    ContactSensor,
    LeakSensor,
    Fan,
    Lock,
    Curtain,
    Custom(String),
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum DeviceStatus {
    Online,
    Offline,
    Provisioning,
    Updating,
    Error,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Device {
    pub id: Id,
    pub name: String,
    pub room_id: Option<Id>,
    pub device_type: String,
    pub capabilities: Vec<DeviceCapability>,
    pub firmware_version: String,
    pub mac_address: String,
    pub ip_address: Option<String>,
    pub status: DeviceStatus,
    pub last_seen: Option<DateTime<Utc>>,
    /// Digital-twin style shadow: last known reported state + desired state.
    pub reported_state: serde_json::Value,
    pub desired_state: serde_json::Value,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
}

impl Device {
    pub fn new(name: impl Into<String>, mac_address: impl Into<String>, device_type: impl Into<String>) -> Self {
        let now = Utc::now();
        Self {
            id: new_id(),
            name: name.into(),
            room_id: None,
            device_type: device_type.into(),
            capabilities: vec![],
            firmware_version: "unknown".into(),
            mac_address: mac_address.into(),
            ip_address: None,
            status: DeviceStatus::Provisioning,
            last_seen: None,
            reported_state: serde_json::json!({}),
            desired_state: serde_json::json!({}),
            created_at: now,
            updated_at: now,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Room {
    pub id: Id,
    pub home_id: Id,
    pub name: String,
    pub icon: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Home {
    pub id: Id,
    pub name: String,
    pub timezone: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct User {
    pub id: Id,
    pub email: String,
    pub display_name: String,
    pub role: UserRole,
    pub password_hash: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum UserRole {
    Owner,
    Admin,
    Member,
    Guest,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum TriggerKind {
    DeviceState { device_id: Id, path: String, op: CompareOp, value: serde_json::Value },
    Schedule { cron: String },
    Sunrise { offset_minutes: i32 },
    Sunset { offset_minutes: i32 },
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum CompareOp {
    Eq,
    Neq,
    Gt,
    Gte,
    Lt,
    Lte,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Condition {
    pub device_id: Id,
    pub path: String,
    pub op: CompareOp,
    pub value: serde_json::Value,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Action {
    pub device_id: Id,
    pub set_state: serde_json::Value,
    pub delay_ms: Option<u64>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Automation {
    pub id: Id,
    pub name: String,
    pub enabled: bool,
    pub trigger: TriggerKind,
    pub conditions: Vec<Condition>,
    pub actions: Vec<Action>,
    pub created_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Scene {
    pub id: Id,
    pub name: String,
    pub actions: Vec<Action>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LogEntry {
    pub id: Id,
    pub level: String,
    pub source: String,
    pub message: String,
    pub timestamp: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Notification {
    pub id: Id,
    pub title: String,
    pub body: String,
    pub read: bool,
    pub created_at: DateTime<Utc>,
}

/// Typed command vocabulary a client can send to a device (design doc section 8).
/// Each variant serializes to the flat JSON shape the ESP32 firmware expects,
/// e.g. `DeviceCommand::Brightness(80)` -> `{"cmd":"brightness","value":80}`.
/// This sits on top of the raw JSON `publish_message`/`DeviceCommand` event —
/// it's a convenience layer, not a replacement, since custom firmware can
/// still accept arbitrary JSON.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "cmd", rename_all = "snake_case")]
pub enum DeviceCommand {
    On,
    Off,
    Toggle,
    Brightness { value: u8 },
    Rgb { r: u8, g: u8, b: u8 },
    FanSpeed { value: u8 },
    ServoAngle { degrees: u16 },
    Schedule { at: DateTime<Utc>, action: Box<DeviceCommand> },
    Restart,
    FactoryReset,
}

impl DeviceCommand {
    pub fn to_json(&self) -> serde_json::Value {
        serde_json::to_value(self).unwrap_or(serde_json::Value::Null)
    }
}

/// Typed response vocabulary a device reports back (design doc section 8).
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "status", rename_all = "snake_case")]
pub enum DeviceResponse {
    Ok,
    Error { message: String },
    Busy,
    Offline,
    Battery { percent: u8 },
    SensorData { payload: serde_json::Value },
    FirmwareVersion { version: String },
}

impl DeviceResponse {
    pub fn from_json(value: &serde_json::Value) -> Option<Self> {
        serde_json::from_value(value.clone()).ok()
    }
}
