# LUMA Rust Core Engine

Cross-platform native core for LUMA. Two design docs are implemented here:
the original layered-engine architecture, and the "phone IS the MQTT broker"
offline-first spec. Both are real, compiling, tested code — not stubs.

## What's new: the embedded MQTT broker

The second design doc's core requirement — the mobile app itself acts as the
local MQTT broker, no internet or external broker required — is now built as
**`luma-broker`**, on top of `mqttbytes` (the lean packet codec rumqttc/rumqttd
use internally; full `rumqttd` was evaluated and rejected — it pulls
rustls/websocket/sled and needs a newer Rust than this environment has, and
is architected for cloud deployment, not a 5-device embedded broker).

**Implemented and proven by 6 integration tests** (`crates/luma-ffi/tests/integration.rs`),
each driving the broker over a **real raw TCP MQTT socket** standing in for
an ESP32 — not calling internals directly:

| Requirement | Test |
|---|---|
| CONNECT/CONNACK, SUBSCRIBE/SUBACK, PUBLISH/PUBACK | `typed_command_delivered_to_subscribed_device` |
| Client Manager, 5-device cap enforced | `max_five_clients_enforced` |
| Device shadow update from sensor data | `sensor_data_updates_device_shadow` |
| Persistent sessions + durable offline queue | `persistent_session_queues_command_while_offline` |
| Retained messages + replay-on-subscribe | `retained_message_replayed_on_subscribe` |
| Engine lifecycle + MQTT Monitor stats | `engine_starts_broker_and_reports_capacity` |

**A real bug the tests caught and fixed:** retained-message replay was
cloning the stored `Publish` (packet id 0) instead of allocating a fresh one
per subscriber. `mqttbytes` correctly rejects QoS≥1 packets with id 0 at
encode time, so the write silently failed and the retained message never
reached new subscribers. Fixed in `luma-broker/src/protocol.rs` — worth
knowing about since it's the kind of bug that only shows up with a wire-level
test, not a unit test against broker internals.

### Broker feature coverage

- **MQTT 3.1.1**: CONNECT/CONNACK, PUBLISH/PUBACK (QoS 0/1 — QoS2 is
  downgraded to QoS1 with a log line, matching the doc's explicit "QoS 0 and
  QoS 1" scope), SUBSCRIBE/SUBACK, UNSUBSCRIBE/UNSUBACK, PINGREQ/PINGRESP,
  DISCONNECT, Last Will, retained messages, keep-alive timeout detection
- **Client Manager** (`client.rs`): MAC/IP/session/last-seen/RSSI, hard cap
  at 5 *connected* sockets (persistent-but-offline sessions don't hold a slot)
- **Topic Manager** (`topics.rs`): wildcard routing (delegates to
  `mqttbytes::matches`), conventions for `device/{mac}/command|status|config|update|data`
  and `home/{room}/{device}` / `home/all`
- **Session Manager**: persistent sessions survive both a client reconnect
  *and* an app restart — offline QoS≥1 publishes queue into a SQLite
  `session_queue` table and replay the instant the client reconnects
- **Reliability**: retry-with-backoff for unacked QoS1 deliveries
  (`inflight.rs`, 3 attempts / 5s apart), automatic reconnect-takeover (a new
  connection with the same client_id cleanly evicts the old socket)
- **Security**: local-trust by default (no auth required, matching "local-only
  communication by default"); optional HMAC device-token auth via
  `luma-security` if `broker_require_auth` is turned on

## Full crate map

```
crates/
  luma-core        Event bus, Engine trait, EngineController, domain models,
                    typed DeviceCommand/DeviceResponse vocabulary (doc §8)
  luma-storage     SQLite: devices/rooms/automations/scenes/logs/
                    session_queue/broker_clients/telemetry
  luma-broker      The embedded MQTT broker — NEW, the phone IS the server
  luma-mqtt        MQTT *client* — now an optional bridge to a remote broker
                    for the "Future Enhancements: secure remote access" bullet
  luma-automation  Rule engine — implements Engine
  luma-security    Argon2 passwords + HMAC device tokens
  luma-ffi         UniFFI-exported LumaApi — the only crate RN/mobile touches
```

Everything communicates through `LumaEvent` on the shared `EventBus` — the
broker never talks directly to automation, automation never talks directly to
the broker. `DeviceCommand` events published by automation, `send_command`,
or `publish_message` are picked up by *both* the broker (delivers locally)
and the cloud bridge if enabled (mirrors upward for remote visibility) —
no special-casing needed.

## What's real vs. still a next step

**Real:** everything in the table above, plus UDP-broadcast discovery and
**real mDNS browsing** (`mdns-sd`, browsing `_luma._tcp.local.` for TXT keys
`mac`/`name`/`type`/`fw`). In practice a device simply *connecting* to the
broker is itself a discovery signal — no scan needed for anything already
provisioned with the broker's address.

**Still stubbed** (unchanged from before, so you know exactly where the
edges are): BLE discovery/provisioning (native Android/iOS — radios aren't
reachable from sandboxed Rust; hook is `report_discovered_device`), OTA
transfer itself (`update_firmware` records intent + emits progress events
with a stable contract), cron/sunrise/sunset automation triggers (the enum
variants exist, only `DeviceState` is evaluated), Analytics engine, Plugin
engine (Zigbee/Thread/Matter/LoRa — `Engine` trait is the extension point).

## Wiring into React Native

1. `cargo build --release -p luma-ffi` → `libluma_ffi.so`/`.a` (cross-compile
   for Android via `cargo-ndk`, iOS via `cargo build --target aarch64-apple-ios`).
2. `cargo run --bin uniffi-bindgen generate --library target/release/libluma_ffi.so --language kotlin` (or `swift`).
3. Wrap the generated `LumaApi` class in a thin TurboModule/native module.
4. From JS: `LumaCore.startEngine()` binds the broker on `broker_port`
   (default 1883) and your ESP32 firmware just points its MQTT client at the
   phone's hotspot/LAN IP — no cloud, no external broker, matching the
   "no internet required" system goal directly.

## Build

```bash
cargo build --workspace
cargo test -p luma-ffi              # 6 tests, real TCP sockets, no broker mocking
cargo build --release -p luma-ffi
```

This environment pins a handful of crypto-adjacent transitive crates
(`uuid`, `base64ct`, `zeroize`, `cpufeatures`, `smawk`, `cargo-platform`) to
slightly older patch versions in `Cargo.lock` — recent releases bumped their
MSRV past this environment's Rust 1.75. On a newer toolchain (1.85+), drop
the pins with `cargo update`.
